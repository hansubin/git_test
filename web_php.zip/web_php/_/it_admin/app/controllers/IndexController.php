<?php

use Phalcon\Mvc\Controller;
use Phalcon\Tag;

class IndexController extends Controller
{
	public static $dbid = 7;//0->live,6->test
	
	public function indexAction()
	{
		//Add some local CSS resources
		$this->assets->addCss('css/style.css');
		$this->view->setVar('title','로그인');
	}	
}