<?php
use Phalcon\Mvc\Controller;

class LoginController extends Controller
{
  private $dbid = 7;
  
	public function indexAction()
	{
		// if (!$this->security->checkToken()) {
			// header("Location:/it_admin/");
			// exit(1);
		// }
		$id = $this->request->getPost('userid','string');
		$pwd = $this->request->getPost('dst_ps','string');

		$stmt = $this->sql->execute(
		"select emp_nm from x_emp_mst where emp_stt = '1' and emp_no ilike :login and emp_pwd = crypt(:pwd, emp_pwd)",
			array(':login'=>$id,':pwd'=>$pwd),$this->dbid);
		$row = $stmt->fetch(PDO::FETCH_ASSOC);

		if ( isset($row['emp_nm']))
		{
			$this->session->set('user',array('it_id'=>$id,'it_nm'=>$row['emp_nm']));
			$this->logger->log('로그인 성공 it id:'.$this->session->get('user')['it_id'].',it_nm:'.$this->session->get('user')['it_nm']);
			header("Location:/it_admin/login/main");
			exit(1);
		}
		else
		{
			$this->logger->log($row['emp_nm'].', 로그인실패 - id:'.$id.',pwd:'.$pwd);
		}
	}
	
	public function mainAction()
	{
		//Add some local CSS resources
		$this->logger->log('login/it_infra_main');
		$this->assets->addJs('js/MyBuilderViewer32U.js');
		$this->view->setVar('lgn_id',$this->session->get('user')['it_id']);
		$this->view->setVar('lgn_nm',$this->session->get('user')['it_nm']);
		$this->view->setVar('title','로그인');
	}
}