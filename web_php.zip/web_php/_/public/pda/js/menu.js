function redirectUser(id){
	if(id == 0)
	{
		window.location = "http://pda.daehyunst.com";
		window.navigate("http://pda.daehyunst.com"); //works only with IE
	}
	else if(id == 1)
	{
		window.location = "http://pda.daehyunst.com/output";
		window.navigate("http://pda.daehyunst.com/output"); //works only with IE
	}
	else if(id == 2)
	{
		window.location = "http://pda.daehyunst.com/aging";
		window.navigate("http://pda.daehyunst.com/aging"); //works only with IE
	}
	else if(id == 3)
	{
		window.location = "http://pda.daehyunst.com/move";
		window.navigate("http://pda.daehyunst.com/move"); //works only with IE
	}
	else if(id == 4)
	{
		window.location = "http://pda.daehyunst.com/output/detail";
		window.navigate("http://pda.daehyunst.com/output/detail"); //works only with IE
	}
	else if(id == 5)
	{
		window.location = "http://pda.daehyunst.com/pack";
		window.navigate("http://pda.daehyunst.com/pack"); //works only with IE
	}
	else if(id == 7)
	{
		window.location = "http://pda.daehyunst.com/check";
		window.navigate("http://pda.daehyunst.com/check"); //works only with IE
	}
	else if(id == 8)
	{
		window.location = "http://pda.daehyunst.com/sal";
		window.navigate("http://pda.daehyunst.com/sal"); //works only with IE
	}
	else if(id == 9)
	{
		window.location = "http://pda.daehyunst.com/sal";
		window.navigate("http://pda.daehyunst.com/reqjob"); //works only with IE
	}
	else if(id == 10)
	{
		window.location = "http://pda.daehyunst.com/home";
		window.navigate("http://pda.daehyunst.com/home"); //works only with IE
	}
	else if(id == 11)
	{
		window.location = "http://pda.daehyunst.com/reqout";
		window.navigate("http://pda.daehyunst.com/reqout"); //works only with IE
	}
	else if(id == 12)
	{
		window.location = "http://pda.daehyunst.com/sal";
		window.navigate("http://pda.daehyunst.com/sal"); //works only with IE
	}	
	else
	{
		window.location = "http://pda.daehyunst.com/home";
		window.navigate("http://pda.daehyunst.com/home"); //works only with IE
	}
}

function clearInput(){
	document.getElementById("b_id").value = '';
}

function increase_num(id){
    var el = document.getElementById(id);
    el.value = el.value - 0 + 1;
    //alert(el.value);
}

function decrease_num(id){
    var el = document.getElementById(id);
    el.value -= 1;
   //alert(el.value);
}