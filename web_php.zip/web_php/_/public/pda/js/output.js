function checkAll(){
	el = document.getElementsByName("chk_all");
	if(el){
		el_sub = document.getElementsByName("chk");
		if(el_sub)
		{
			if(el[0].checked){
				for( i = 0; i < el_sub.length; i++) el_sub[i].checked = true;
			}
			else{
				for( i = 0; i < el_sub.length; i++) el_sub[i].checked = false;
			}
		}
	}
}

function selectedMove(move_str){
	var el = document.getElementsByName("chk");
	if(el){
		var arr = [];
		for( i = 0; i < el.length; i++) {
			if(el[i].checked)arr.push('1');
			else arr.push('0');
		}
		post(move_str,arr);
	}
}

function arrPost(move_str,name){
	var el = document.getElementsByName(name);
	if(el){
		var params = new Array();
		for( i = 0; i < el.length; i++) {
			params.push(el[i].value);
		}
	}
	var form = document.createElement("form");
	form.setAttribute("method", "post");
	form.setAttribute("action", move_str);

	post(move_str,params);
}

function arrPost2(move_str,name1,name2){
	var el1 = document.getElementsByName(name1);
	if(el1){
		var params1 = new Array();
		for( i = 0; i < el1.length; i++) {
			params1.push(el1[i].value);
		}
	}
	var el2 = document.getElementsByName(name2);
	if(el2){
		var params2 = new Array();
		for( i = 0; i < el2.length; i++) {
			params2.push(el2[i].value);
		}
	}
	var params = new Array();
	params[0] = new Array();
	params[0] = params1;
	params[1] = new Array();
	params[1] = params2;
//	alert(params);
	var form = document.createElement("form");
	form.setAttribute("method", "post");
	form.setAttribute("action", move_str);

	post(move_str,params);
}

function post(path, params) {
	var form = document.createElement("form");

	form.setAttribute("method", "post");
	form.setAttribute("action", path);

	for(var key in params) {
		if(params.hasOwnProperty(key)) {
			var hiddenField = document.createElement("input");
			hiddenField.setAttribute("type", "hidden");
			hiddenField.setAttribute("name", key);
			hiddenField.setAttribute("value", params[key]);
			form.appendChild(hiddenField);
		}
	}

	document.body.appendChild(form);
	form.submit();
}