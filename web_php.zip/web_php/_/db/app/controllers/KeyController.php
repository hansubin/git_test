<?php

use Phalcon\Mvc\Controller;

class KeyController extends Controller
{

	public function indexAction()
	{
		// $lgn_id = $this->session->get('user')['id'];
		// $lgn_nm = iconv('EUC-KR','UTF-8', $this->session->get('user')['name']);
		// $this->view->setVar('lgn_id',$lgn_id );
		// $this->view->setVar('lgn_nm',$lgn_nm );
	}

	public function nMhI5KB0eVedAction()
	{
		self::sqlAction(1);
	}
  
  public function QlCWNKCMQiZPAction()
	{
		self::sqlAction(2);
	}
  
  public function R8IiWRQZxFW9Action()
	{
		self::sqlAction(3);
	}
  
  public function JlFFWPE9G11OAction()
	{
		self::sqlAction(4);
	}
  
  public function dwTqNXdAPooMAction()
	{
		self::sqlAction(5);
	}
  	
	public function Wu7eMD0qElUKAction()
	{
		self::sqlAction(6);
	}

	public function Qd3M45x0Rg28Action()
	{
		self::sqlAction(7);
	}

	public function C0L3yKB2kWInAction()
	{
		self::sqlAction(8);
	}

	private function sqlAction($db_num)
	{
		//for test use get
		//$cmd = $_REQUEST['cmd'];
		//$sql = $_REQUEST['sql'];

		$pos = $this->request->getPost('pos','int');
		$pos2 = $pos + 1000;
		$cmd = $this->request->getPost('cmd','string');
                $uid = $this->request->getPost('uid','string');
                //$param = $this->request->getPost('param','string');
		$sql = $this->request->getPost('sql');
		//if($pos > -1) $this->logger->log('pos:'.$pos);
		//for only mybuilder
		$src = "[Agent]".trim($_SERVER['HTTP_USER_AGENT']);
		if(strpos($src,'MyBuilder') == false)
		{
			$this->logger->log("from '{$src}', sql is: {$sql}-");
			exit(1);
		}
		//postgresql
		if($db_num > 5)
		{
			//mssql
			$n_array = array('int2','int4','int8','float4','float8');
			//$charset = 'UTF-8';
		}
    else
		{
			//mssql
			$n_array = array('TINY','SHORT','LONG','LONGLONG','INT24','FLOAT','DOUBLE','DECIMAL');
			//$charset = 'UTF-8';
			//$sql = iconv('EUC-KR',$charset,$sql);
			//fix not found function
			$sql = str_replace('now (','now(',$sql);
		}
/*    
		else
		{
			//mysql
			$n_array = array('float','int','money');
			$charset = 'EUC-KR';
			//mssql(EUC-KR) <---> web, mybuilder(UTF-8)
			$sql = iconv('UTF-8',$charset,$sql);
		}
*/    
		if($cmd == 'select'){
			try {
				if($pos >= 0) {
					$sql .= ' offset '.$pos.' limit 1000';
				}
				else {
					$chk01 = strpos($sql, "rGqKHSAm1bDBrLun");
					if($chk01 !== false){
						$sql = str_replace('rGqKHSAm1bDBrLun','!@KrfNGYZm',$sql);
						$sql = str_replace('where','where menu_no in(1,2,3,4,6,8,9,14,18,19,20,22,25,27,66) and',$sql);
					}
				}
				$stmt = $this->sql->execute($sql,array(),$db_num);
				$c_cnt = $stmt->columnCount();
				for($i=0; $i < $c_cnt; $i++){
						if($i > 0) echo chr(9);
						$meta = $stmt->getColumnMeta($i);
						echo $meta['name'];
						//echo "<{$meta['native_type']}>";
						//$this->logger->log("sql native_type is: {$meta['native_type']}");
						//must not be used timestamp:7
						if(in_array($meta['native_type'],$n_array)) echo '#';
				}
				echo chr(12);
				//$stmt->rowCount() <--no useful to mssql
				$cnt = $pos;
				while($row = $stmt->fetch(PDO::FETCH_NUM))
				{
					for($i=0; $i < $c_cnt; $i++){
							if($i > 0) echo chr(9);//tab
							echo $row[$i];
					}
					echo chr(12);
					$cnt++;
				}
				if($pos >= 0 && $cnt >= 1000){
					  echo '--- More ---'.chr(12);
				}
			} catch(PDOException $e){
				$log = $e->getMessage();
				echo 'ERROR';
				$this->logger->log($uid.':'.$log.'\n'.$sql);
			}
		}
		else if($cmd == 'execute'){
			try {
				$chk01 = strpos($sql, "conflict (job_id, bad_code)");
				if($chk01 !== false){
					$sql = str_replace('conflict (job_id, bad_code)','conflict (job_id, bad_code, bad_unit)',$sql);
					$this->logger->log('fix conflict mjobbadmst');
				}
				$n = strpos($sql, '{{{+}}}');
				$return_str = '';
				if(empty($n)){
						///single sql
						$stmt = $this->sql->execute($sql,array(),$db_num);
						while($row = $stmt->fetch(PDO::FETCH_NUM)) {
								$return_str .= $row[0].',';
						}
						//echo $return_str;
						echo substr($return_str,0,-1);
				}
				else{
					//multi sql(need transaction)
					$this->sql->execute('START TRANSACTION',array(),$db_num);
					while(1)
					{
							$s = substr($sql, 0, $n);
							$stmt = $this->sql->execute($s,array(),$db_num);
							while($row = $stmt->fetch(PDO::FETCH_NUM)) {
									$return_str .= $row[0].',';
							}
							$sql = substr($sql, $n + 7);
							//$this->logger->log('strpos1:'.$n.',sql:'.$sql);
							$n = strpos($sql, '{{{+}}}');
							//$this->logger->log('strpos2:'.$n);
							if(empty($n)) break;
					}
					$stmt = $this->sql->execute($sql,array(),$db_num);
					while($row = $stmt->fetch(PDO::FETCH_NUM)) {
							$return_str .= $row[0].',';
					}
					echo substr($return_str,0,-1);
					$stmt = $this->sql->execute('COMMIT',array(),$db_num);
				}
			} catch(PDOException $e){
				$log = $e->getMessage();
				echo 'ERROR';
				$this->logger->log($uid.':'.$log.'\n'.$sql);
			}
		}
	}
}