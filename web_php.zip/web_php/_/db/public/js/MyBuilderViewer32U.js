//MBV32,64 UNICODE Version
var plugin_version = "6.2.3.11";


if(navigator.userAgent.indexOf("Trident") != -1 || navigator.userAgent.indexOf("MSIE") != -1) 
{

	if (navigator.platform == "Win64")
	{	// IE 64bit ����ڿ��� ��ġ�Ǵ� ���
		document.write('<object classid=clsid:82D49DBC-7C99-43F2-902A-9BF4F77DC51F id=View1 width=100% height=100% align=left ');
		document.write('codebase="http://erp.daehyunst.com/dstmyb/Biin/MyBuilderViewer64U.cab#version=6,2,3,12"></object>');
	}
	else
	{
		if (navigator.appVersion.indexOf("Windows NT 6") != -1)
		{	// IE 32bit ����ڿ��� ��ġ�Ǵ� ���
			document.write('<object classid=clsid:68C56CFC-078F-4440-BB2C-0C8EF487B210 id=View1 width=100% height=100% align=left ');
			document.write('codebase="http://erp.daehyunst.com/dstmyb/Biin/MyBuilderViewer32U.cab#version=6,2,3,12"></object>');
		}
		else
		{	// Windows XP ����ڿ��� ��ġ�Ǵ� ���
			document.write('<object classid=clsid:15476266-9094-4F36-9895-0E670A392A93 id=View1 width=100% height=100% align=left ');
			document.write('codebase="http://erp.daehyunst.com/dstmyb/Biin/MyBuilderViewerU.cab#version=6,2,3,12"></object>');
		}
	}
}
else
{	// Chrome, Firefox, Safari, Opera���� ����ϴ� Viewer Plug-in.
	if (checkPluginVersion())
	{
	//return true;
		document.write('<embed type=application/mybuilder-unicode-plugin id=View1 width=100% height=800 align=left>');
	}
	else
	{
	//return false;
		alert("Download Mybuilder Plug-in. \n Please restart browser after install Plug-in.");
		location.href = "http://erp.daehyunst.com/dstmyb/Biin/MyBuilderViewerU" + plugin_version + ".exe";
	}
}

window.onerror = function(ErrorMessage, Url, Line)
{
	window.status = '';
	return true;
}

function checkPluginVersion()
{	
	
	for (i=0; i<navigator.plugins.length; i++)
	{
	
		if (navigator.plugins[i].description == "MyBuilder Viewer Unicode")
		{
			var startPos = navigator.plugins[i].name.indexOf('6');
			var stringLength = navigator.plugins[i].name.length;
			var installVersion = navigator.plugins[i].name.substring(startPos, stringLength);
			var installArray = installVersion.split('.');
			var pluginArray = plugin_version.split('.');

			// ��ġ�� ������ ���ǵ� �������� ũ�� ��ġX
			if(parseInt(installArray[2],10) > parseInt(pluginArray[2],10)) {
				return true;
			} else if(parseInt(installArray[2],10) == parseInt(pluginArray[2],10)){
				if(parseInt(installArray[3],10) >= parseInt(pluginArray[3],10)) {
					return true;
				} else {
					return false;
				}
			} else {
					return false;
			}
			
			alert("Mybuilder Plugin was updated...\nDelete previous MyBuilderViewer and New install.");
		
		}
	}

}



