<?php
use Phalcon\Mvc\Controller;
use Phalcon\Tag;
class PageController extends Controller
{
	function getLink($linkStr)
	{
		return "http://pda.daehyunst.com/".$linkStr;
	}
	
	function bottom($param)
	{
		$maxList 	= $param["maxList"];	// Max List Count per page
		$maxPage 	= $param["maxPage"];	// Max Page Count per document
		$cPage 		= $param["cPage"];		// Current Page
		$totCount 	= $param["totCount"];	// Total List Count
		$link 		= $param["link"];
		$font_size 	= $param["font_size"];
		$half_size	= round(intval($font_size) / 2,0);
		$fix_color	= $param["fix_color"];
		$link_color	= $param["link_color"];
		$tags = '';
		
		if($maxList == "" || $maxList == 0)	$maxList = 1;
		if($maxPage == "" || $maxPage == 0)	$maxPage = 4;
		if($cPage == "" || $cPage == 0)	$cPage = 1;
		
		if($totCount == 0) {
			$totPage = 1;
		}
		else {
			$totPage = intval($totCount / $maxList);
			if( ($totCount%$maxList) > 0)
				$totPage++;		
		}
		
		$firPage = $cPage - intval($maxPage / 2)+1;
		if($firPage < 1)	$firPage = 1;
		$lastPage = $firPage + ($maxPage-1);
		if($lastPage >= $totPage)	$lastPage = $totPage;

		if(strpos($link,"?") === false)
			$linkStr = $link."?page=";
		else 
			$linkStr = $link."&page=";

		if($firPage > 1){
			$tags .= "<a href=\"".self::getLink($linkStr.'1')."\" ><span style='color:".$fix_color.";text-decoration:underline;font-size:".$font_size."px;margin:0px 0px 0px 0px;'>1</span></a><span style='color:".$fix_color.";font-size:".$font_size."px;margin:0px 0px 0px 0px;'> .. </span>";
		}
		for($i=$firPage; $i<=$lastPage; $i++) {
			if($i == $cPage){
				$tags .= "<span style='font-size:".$font_size."px;color:".$fix_color.";margin-right:".$half_size."px;'>".$i."</span>";
			}
			else{ 
				if($i == $lastPage){
					$tags .= " <a href=\"".self::getLink($linkStr.$i)."\" ><span style='color:".$link_color.";text-decoration:underline;font-size:".$font_size."px;margin:0px 0px 0px 0px;'>".$i."</span></a> ";
				} else{
					$tags .= " <a href=\"".self::getLink($linkStr.$i)."\" ><span style='color:".$link_color.";text-decoration:underline;font-size:".$font_size."px;margin:0px ".$half_size."px 0px 0px;'>".$i."</span></a> ";
				}
			}
		}
		if($lastPage < $totPage){
			$tags .= "<span style='color:".$fix_color.";font-size:".$font_size."px;margin:0px 0px 0px 0px;'> .. </span><a href=\"".self::getLink($linkStr.$totPage)."\" ><span style='color:".$link_color.";text-decoration:underline;font-size:".$font_size."px;margin:0px 0px 0px 0px;'>".$totPage."</span></a>";
		}
			
		return $tags;

	}

	function top($param)
	{
		global $current_controller;

		$maxList 	= $param["maxList"];	// Max List Count per page
		$maxPage 	= $param["maxPage"];	// Max Page Count per document
		$cPage 		= $param["cPage"];		// Current Page
		$totCount 	= $param["totCount"];	// Total List Count
		$link 		= $param["link"];
		
		if($maxList == "" || $maxList == 0)	$maxList = 1;
		if($maxPage == "" || $maxPage == 0)	$maxPage = 1;
		if($cPage == "" || $cPage == 0)	$cPage = 1;
		
		if($totCount == 0) {
			$totPage = 1;
		}
		else {
			$totPage = intval($totCount / $maxList);
			if( ($totCount%$maxList) > 0)
				$totPage++;		
		}
		
		
		if($current_controller->config->isSmartPhone()) {
			$t_prev = "<img src='".$current_controller->config->getSiteUrl()."/sp/img/common/prev.png' width='102' height='32'/>";
			$t_next = "<img src='".$current_controller->config->getSiteUrl()."/sp/img/common/next.png' width='102' height='32'/>";
			
			$t_prev_b = "<img src='".$current_controller->config->getSiteUrl()."/sp/img/common/b_prev.png' width='102' height='32'/>";
			$t_next_b = "<img src='".$current_controller->config->getSiteUrl()."/sp/img/common/b_next.png' width='102' height='32'/>";
			
		} else {
			$t_prev = "멟귉(*)";
			$t_next = "렅귉(#)";
		}
		
		
		$tags = "";
		if(strpos($link,"?") === false)
			$linkStr = $link."?page=";
		else 
			$linkStr = $link."&page=";
		
		

		if($current_controller->config->isSmartPhone()) { 
			
			if($cPage > 1)
				$tags .= "<a href=\"".getLink($linkStr.($cPage-1))."\"><span style='color:#00aeff;text-decoration:underline;'>".$t_prev."</span></a>";
			else 
				$tags .= "".$t_prev_b."";
			$tags .= " [".$cPage."/".$totPage."] ";
			if($cPage < $totPage)
				$tags .= "<a href=\"".getLink($linkStr.($cPage+1))."\"><span style='color:#00aeff;text-decoration:underline;'>".$t_next."</span></a>";
			else 
				$tags .= "".$t_next_b."";
		} 
		else {
			
			if($cPage > 1)
				$tags .= "<a href=\"".getLink($linkStr.($cPage-1))."\" accesskey=*><span style='color:#00aeff;text-decoration:underline;'>".$t_prev."</span></a>";
			else
				$tags .= "".$t_prev."";
			$tags .= " [".$cPage."/".$totPage."] ";
			if($cPage < $totPage)
				$tags .= "<a href=\"".getLink($linkStr.($cPage+1))."\" accesskey=#><span style='color:#00aeff;text-decoration:underline;'>".$t_next."</span></a>";
			else
				$tags .= "".$t_next."";
		}
		
			
		return $tags;

	}
}