<?php
use Phalcon\Mvc\Controller;
use Phalcon\Tag;

class ReqjobController extends Controller
{
	public static $dbid = 6;//0->live,6->test
	
	public function indexAction()
	{
		$this->view->setVar('scale',1);
		$this->view->setVar('d_width',375);
		$this->assets->addJs('js/output.js?'.time());
		$this->assets->addJs('js/menu.js?'.time());
		$this->assets->addCss('css/style.css?'.time());
		$this->view->setVar('title','생산의뢰');
	}

	public function listAction()
	{
		//파라미터 해석
		$page = $this->request->get('page');
		if(isset($page)) {
			//품목
			$itm_name = $this->session->get('itm_name');
			$itm_width = intval($this->session->get('itm_width'));
			$itm_length = intval($this->session->get('itm_length'));
			//거래처
			$cst_name = $this->session->get('cst_name');
		}
		else {
			//품목
			$itm_name = $this->request->getPost('itm_name');
			if($itm_name == '상품명 폭 길이') $itm_name = '';
			$itm_arr = explode(' ',$itm_name);
			$tmp_cnt = count($itm_arr);
			$itm_width = 0;
			$itm_length = 0;
			if($tmp_cnt == 1) $itm_name = $itm_arr[0];
			else if($tmp_cnt < 3)
			{
				$itm_name = $itm_arr[0];
				$itm_width = intval($itm_arr[1]);
			}				
			else if($tmp_cnt < 4)
			{
				$itm_name = $itm_arr[0];
				$itm_width = intval($itm_arr[1]);
				$itm_length = intval($itm_arr[2]);
				//$this->logger->log('$itm_arr[1]:'.$itm_arr[1].',itm_width:'.$itm_width);
			}
			$this->session->set('itm_name',$itm_name);
			$this->session->set('itm_width',$itm_width);
			$this->session->set('iztm_length',$itm_length);
			//거래처
			$cst_name = $this->request->getPost('cst_name');
			$this->session->set('cst_name',$cst_name);
		}

		//패이지 정보
		if($page < 1) $page = 1;
		$maxList = 15;
		$maxPage = 7;
		$offset = ($page - 1) * $maxList;

		$where_add = '';
		if($itm_name > '') {
			$itm_name_var = $itm_name;
			$itm_name = "%".$itm_name."%";
			$where_name = " where c.itm_name ilike :itm_name ";
			$params = array(':itm_name'=>$itm_name,':offset'=>$offset,':limit'=>$maxList);
		}
		else{
			$where_name = '';
			$params = array(':offset'=>$offset,':limit'=>$maxList);
		}
		if($itm_width > 0)
		{
			$where_add .= ' and c.itm_width = :itm_width ';
			$params[':itm_width'] = $itm_width;
			$itm_name_var = $itm_name.' '.$itm_width;
		}
		if($itm_length > 0)
		{
			$where_add .= ' and c.itm_length = :itm_length ';
			$params[':itm_width'] = $itm_width;
			$params[':itm_length'] = $itm_length;
			$itm_name_var = $itm_name.' '.$itm_width.' '.$itm_length;
		}
		
		if($cst_name > '') {
			$params[':cst_alias'] = $cst_name;
			if($itm_name > '') $where_add .= ' and d.cst_alias ilike :cst_alias or c.cst_code ilike :cst_alias';
			else $where_add .= ' where d.cst_alias ilike :cst_alias or c.cst_code ilike :cst_alias';
		}
		$count = 0;
		try {
			$query = "select count(*) OVER() AS full_count,max(a.req_code) as req_code, 0 as job_order, max(c.insert_dt) as insert_dt, '' as stat, 0 as task_id, max(a.task_part) as task_part, max(a.ord_id) as ord_id, max(c.ord_part) as ord_part, max(a.req_date) as req_date, max(a.itm_stat) as itm_stat, max(d.cst_date) as cst_date, max(d.cst_finish) as cst_finish, max(d.cst_type) as cst_type, max(c.itm_name) as itm_name, max(c.itm_width) as itm_width, max(c.itm_size) as itm_size, max(c.itm_length) as itm_length, max(c.end_date) as end_date, max(c.ord_qty) as ord_qty, max(c.cst_code) as cst_code, max(c.ord_chk) as ord_chk, max(c.ord_remark) as ord_remark, max(c.content) as content, max(d.cst_alias) as cst_alias, '' as g_content, max(case when d.emp_code > '' then f.emp_nm else e.emp_nm end) as emp_nm, max(case when g.ord_qty is null then c.ord_qty else g.ord_qty end) as last_ord_qty, max(k.task_date) as task_date, max(case when b.job_id > 0 then k.task_date else '' end) as job_date, max(h.ship_date) as ship_date, ARRAY_TO_STRING (ARRAY_AGG (h.ship_qty), ',') as ship_qty, ARRAY_TO_STRING (ARRAY_AGG (case when b.lot_no > '' then b.lot_no else null end), ',') as lot_no from mSalesReqMst a inner join mSalesOrdList c on a.ord_id = c.ord_id left join mSalesOrdModify g on a.ord_id = g.ord_id and g.sal_id = (select max(sal_id) as sal_id from msalesordmodify where ord_id = a.ord_id) left join xCstMst d on c.cst_code = d.cst_code left join xEmpMst e on c.emp_no = e.emp_no left join xEmpMst f on d.emp_code = f.emp_no left join mTaskListMst k on k.req_code = a.req_code and k.equ_code > '*' left join mJobListMst b on k.task_id = b.task_id left join mSalesShipList h on a.req_code = h.req_code and h.ship_date > ''".$where_name.$where_add." and c.ord_part < 19 group by a.req_code order by a.req_code desc offset :offset limit :limit";
			$stmt = $this->sql->execute($query,$params,self::$dbid);
			$rdata = $stmt->fetchAll(PDO::FETCH_ASSOC);
			$count = intval($rdata[0]['full_count']);
			//$this->logger->log(IndexController::pdo_sql_debug($query,$params));
			foreach ($rdata as $key => $value) {
				if($rdata[$key]['task_date'] > '') $rdata[$key]['task_date'] = substr($rdata[$key]['task_date'],4,2).'/'.substr($rdata[$key]['task_date'],-2);
				if($rdata[$key]['job_date'] > '') $rdata[$key]['job_date'] = substr($rdata[$key]['job_date'],4,2).'/'.substr($rdata[$key]['job_date'],-2);
				if($rdata[$key]['ship_date'] > '') $rdata[$key]['ship_date'] = substr($rdata[$key]['ship_date'],4,2).'/'.substr($rdata[$key]['ship_date'],-2);
			}
			$this->view->setVar('rdata',$rdata);
		} catch (PDOException $e) {
			$log = $e->getMessage();
			$this->logger->log($log);
			$this->view->setVar('c_data', '데이터가 없습니다.&#13;&#10;다시 시도해 주십시오.');
			$err = true;
		}
		$bottom = PageController::bottom(array('maxList'=>$maxList,'maxPage'=>$maxPage,'cPage'=>$page,'totCount'=>$count,'link'=>'reqjob/list','font_size'=>20,'fix_color'=>'#000000','link_color'=>'#00aeff',));
		$this->view->setVar('scale',1);
		$this->view->setVar('d_width',375);
		$this->view->setVar('bottom',$bottom);
		$this->view->setVar('itm_name',$itm_name_var);
		$this->view->setVar('cst_name',$cst_name);
		$this->assets->addJs('js/output.js?'.time());
		$this->assets->addJs('js/menu.js?'.time());
		$this->assets->addCss('css/style.css?'.time());
		$this->view->setVar('title','생산의뢰');
	}
}
?>