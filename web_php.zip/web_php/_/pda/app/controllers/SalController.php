<?php
use Phalcon\Mvc\Controller;
use Phalcon\Tag;

class SalController extends Controller
{
	public static $dbid = 6;//0->live,6->test
	
	public function indexAction()
	{
		$this->assets->addJs('js/output.js?'.time());
		$this->assets->addJs('js/menu.js?'.time());
		$this->assets->addCss('css/style.css?'.time());
		$this->view->setVar('title','가용재고');
	}

	public function listAction()
	{
		//파라미터 해석
		$page = $this->request->get('page');
		if(isset($page)) {
			$itm_name = $this->session->get('itm_name');
			$itm_width = intval($this->session->get('itm_width'));
			$itm_length = intval($this->session->get('itm_length'));
			//$this->logger->log('itm_name from session:'.$itm_name);
		}
		else {
			$itm_name = $this->request->getPost('itm_name');
			$itm_arr = explode(' ',$itm_name);
			$tmp_cnt = count($itm_arr);
			$itm_width = 0;
			$itm_length = 0;
			if($tmp_cnt == 1) $itm_name = $itm_arr[0];
			else if($tmp_cnt < 3)
			{
				$itm_name = $itm_arr[0];
				$itm_width = intval($itm_arr[1]);
			}				
			else if($tmp_cnt < 4)
			{
				$itm_name = $itm_arr[0];
				$itm_width = intval($itm_arr[1]);
				$itm_length = intval($itm_arr[2]);
				//$this->logger->log('$itm_arr[1]:'.$itm_arr[1].',itm_width:'.$itm_width);
			}				
			
			//$this->logger->log('itm_name from post:'.$itm_name);
		}
		if(isset($itm_name)) $itm_name = "%".$itm_name."%";
		$this->session->set('itm_name',$itm_name);
		$this->session->set('itm_width',$itm_width);
		$this->session->set('itm_length',$itm_length);
		//패이지 정보
		if($page < 1) $page = 1;
		$maxList = 10;
		$maxPage = 7;
		$offset = ($page - 1) * $maxList;

		//쿼리전 쿼리
		$query = 'select last_month from mInvOpt where opt_id = 1';
		$params = array();
		$stmt = $this->sql->execute($query,$params,self::$dbid);
		$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$last_prev_month = $data[0]['last_month'].'00';
		$tmp_prev_month = $data[0]['last_month'];

		$where_add = '';
		$params = array(':itm_name'=>$itm_name,':last_prev_month'=>$last_prev_month,':tmp_prev_month'=>$tmp_prev_month,':offset'=>$offset,':limit'=>$maxList);
		if($itm_width > 0)
		{
			$where_add .= ' and b.itm_width = :itm_width ';
			$params[':itm_width'] = $itm_width;
		}
		if($itm_length > 0)
		{
			$where_add .= ' and b.itm_length = :itm_length ';
			$params[':itm_width'] = $itm_width;
			$params[':itm_length'] = $itm_length;
		}
		$count = 0;
		try {
			$query = "select count(*) OVER() AS full_count, max(itm_ucode) as itm_ucode,itm_code,max(itm_name) as itm_name,max(itm_width) as itm_width,max(itm_length) as itm_length, sum(itm_ea) as itm_ea, sum(qty) as qty ".
				"from (".
					"select b.itm_ucode,a.itm_code,b.itm_name,b.itm_width,b.itm_length,".
						"case when use_for > '4' or his_part in('2','3','M','R') then -itm_ea else itm_ea end as itm_ea,".
						"case when use_for > '4' or his_part in('2','3','M','R') then -qty else qty end as qty ".
						"from minvhistory a inner join mitmmst b on a.itm_code = b.itm_code ".
						"where b.itm_ucode in('40001','40003') and b.itm_name ilike :itm_name and a.move_date > :last_prev_month ".
						$where_add.
					"union all ".
					"select b.itm_ucode,b.itm_code,c.itm_name,c.itm_width,c.itm_length,b.itm_ea,b.itm_qty as qty ".
						"from mInvTakeStock b inner join mitmmst c on b.itm_code = c.itm_code ".
						"where b.itm_ucode in('40001','40003') and b.itm_name ilike :itm_name and b.job_month = :tmp_prev_month ".
						$where_add.
					"union all ".
					"select b.itm_ucode,b.itm_code,b.itm_name,b.itm_width,b.itm_length,-c.itm_length_in_ready as itm_ea,-b.itm_width * b.itm_length * c.itm_length_in_ready * 0.001 as qty ".
						"from mtasklistmst a ".
						"inner join mitmmst d on a.itm_code = d.itm_code ".
						"inner join mtaskinputitm c on a.task_date = c.task_date and a.equ_code = c.equ_code and d.itm_code = c.itm_code_ready ".
						"inner join mitmmst b on c.bitm_code_ready = b.itm_code ".
						"where b.itm_ucode in('40001','40003') and a.task_date >= to_char(current_date,'YYYYMMDD') and b.itm_name ilike :itm_name ".
						$where_add.
				 ") z ".
				 "group by itm_code ".
				 "order by itm_ucode,itm_name,itm_width desc,itm_length desc offset :offset limit :limit";
			$stmt = $this->sql->execute($query,$params,self::$dbid);
			$rdata = $stmt->fetchAll(PDO::FETCH_ASSOC);
			//$this->logger->log(IndexController::pdo_sql_debug($query,$params));
			$count = intval($rdata[0]['full_count']);
			//$this->logger->log(IndexController::pdo_sql_debug($query,$params));
			//$this->logger->log('data count:'.$count);
			$this->view->setVar('rdata',$rdata);
		} catch (PDOException $e) {
			$log = $e->getMessage();
			$this->logger->log($log);
			$this->view->setVar('c_data', '데이터가 없습니다.&#13;&#10;다시 시도해 주십시오.');
			$err = true;
		}
		$bottom = PageController::bottom(array('maxList'=>$maxList,'maxPage'=>$maxPage,'cPage'=>$page,'totCount'=>$count,'link'=>'sal/list','font_size'=>14,'fix_color'=>'#000000','link_color'=>'#00aeff',));
		$this->view->setVar('bottom',$bottom);
		$this->assets->addJs('js/output.js?'.time());
		$this->assets->addJs('js/menu.js?'.time());
		$this->assets->addCss('css/style.css?'.time());
		$this->view->setVar('title','가용재고');
	}

	public function stockAction() {
		try {
		  $stmt = $this->sql->execute($sql,array(),$db_num);
		  while($row = $stmt->fetch(PDO::FETCH_NUM)) {
			$return_str .= $row[0].',';
		  }
		} catch(PDOException $e){
			$log = $e->getMessage();
			echo 'ERROR';
			$this->logger->log($uid.':'.$log.'\n'.$sql);
		}
		//Add some local CSS resources
		$this->assets->addCss('css/style.css');
		$this->view->setVar('title','로그인');
	}

	public function requestAction()
	{
		//Add some local CSS resources
		$this->assets->addCss('css/style.css');
		$this->view->setVar('title','로그인');
	}	
}
?>