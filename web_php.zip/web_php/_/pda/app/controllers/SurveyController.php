<?php

use Phalcon\Mvc\Controller;

class SurveyController extends Controller
{

    public function indexAction()
    {	

	}
	
	public function rcodeAction()
	{
		//$rcode = $this->request->getPost('rcode');
		//$this->view->setVar('rcode',$rcode);
		
		 $this->dispatcher->forward(
            [
                "controller" => "survey",
                "action"     => "index",
            ]
        );
	}
	
	public function retireAction(){
		
	}
	
	public function completeAction()
	{
		
		$dept = $this->request->getPost('dept');
		$age = $this->request->getPost('age');
		$gender = $this->request->getPost('gender');
		$period = $this->request->getPost('period');
		$retire_reason = $this->request->getPost('selector1');
		$culture = $this->request->getPost('selector2');
		$promotion = $this->request->getPost('selector3');
		$salary = $this->request->getPost('selector4');
		$welfare = $this->request->getPost('selector5');
		$free_word = $this->request->getPost('wantText');
		
		//$bro = $session -> getId();
		//$this->view->setVar('bro',$bro);
		
		try{
			
			$insert_txt = "('" .$dept . "','" .$age. "','" .$gender. "','"
		.$period. "','" .$retire_reason. "','" .$free_word.
		"','" .$culture. "','" .$promotion. "','" .$salary. "','" .$welfare. "')";
		
		$query = "insert into mretire(dept,age,gender,work_period,retire_reason,free_word,culture,promotion,salary,welfare)values "
		.$insert_txt;
		
		$params = array();
		$stmt = $this->sql->execute($query,$params);
		
		}catch(PDOException $e){
			$log = $e->getMessage();
            $this->logger->log($log);
		}		
	}
	
	
	public function csAction()
	{
		//cs컨트롤러에서 넘어왓다.
	}
	
	//한국어일시
	public function csconAction()
	{
		$company = $this->request->getPost('company');
		$dept = $this->request->getPost('dept');
		$name = $this->request->getPost('name');
		$qns1 = $this->request->getPost('qns1');
		$qns2 = $this->request->getPost('qns2');
		$qns3 = $this->request->getPost('qns3');
		$qns4 = $this->request->getPost('qns4');
		$qns5 = $this->request->getPost('qns5');
		$qns6 = $this->request->getPost('qns6');
		$qns7 = $this->request->getPost('qns7');
		$qns8 = $this->request->getPost('qns8');
		$qns9 = $this->request->getPost('qns9');
		$qns10 = $this->request->getPost('qns10');
		$qns11 = $this->request->getPost('qns11');
		$qns12 = $this->request->getPost('qns12');
		$qns13 = $this->request->getPost('qns13');
		$qns_text1 = $this->request->getPost('qns_text1');
		$qns_text2 = $this->request->getPost('qns_text2');
		$qns_text3 = $this->request->getPost('qns_text3');
		$lang = "ko";
		try{
		$insert_txt = "('" .$company . "','" .$dept. "','" .$name. "',"
		.$qns1. "," .$qns2. "," .$qns3. "," .$qns4. "," .$qns5. "," .$qns6
		. "," .$qns7. "," .$qns8. "," .$qns9. "," .$qns10
		. "," .$qns11. "," .$qns12."," .$qns13.",'"
		.$qns_text1."','" .$qns_text2."','" .$qns_text3. "','" .$lang. "')";
		
		$query = "insert into mcssurvey(company,dept,name,qns1,qns2,qns3,qns4,qns5,qns6,qns7,qns8,qns9,qns10,qns11,qns12,qns13,qns_text1,qns_text2,qns_text3,lang)values "
		.$insert_txt;
		
		$params = array();
		$stmt = $this->sql->execute($query,$params);
		
		}catch(PDOException $e){
			$log = $e->getMessage();
            $this->logger->log($log);
		}
	
	
	
	}
	
	
	
	
	public function csenAction()
	{
		//csen컨트롤러에서 넘어왓다.
	}
	
	//영어일시
	public function csconenAction()
	{
		$company = $this->request->getPost('company');
		$dept = $this->request->getPost('dept');
		$name = $this->request->getPost('name');
		$qns1 = $this->request->getPost('qns1');
		$qns2 = $this->request->getPost('qns2');
		$qns3 = $this->request->getPost('qns3');
		$qns4 = $this->request->getPost('qns4');
		$qns5 = $this->request->getPost('qns5');
		$qns6 = $this->request->getPost('qns6');
		$qns7 = $this->request->getPost('qns7');
		$qns8 = $this->request->getPost('qns8');
		$qns9 = $this->request->getPost('qns9');
		$qns10 = $this->request->getPost('qns10');
		$qns11 = $this->request->getPost('qns11');
		$qns12 = $this->request->getPost('qns12');
		$qns13 = $this->request->getPost('qns13');
		$qns_text1 = $this->request->getPost('qns_text1');
		$qns_text2 = $this->request->getPost('qns_text2');
		$qns_text3 = $this->request->getPost('qns_text3');
		$lang = "en";
		
		try{
		$insert_txt = "('" .$company . "','" .$dept. "','" .$name. "',"
		.$qns1. "," .$qns2. "," .$qns3. "," .$qns4. "," .$qns5. "," .$qns6
		. "," .$qns7. "," .$qns8. "," .$qns9. "," .$qns10
		. "," .$qns11. "," .$qns12."," .$qns13.",'"
		.$qns_text1."','" .$qns_text2."','" .$qns_text3. "','" .$lang. "')";
		
		$query = "insert into mcssurvey(company,dept,name,qns1,qns2,qns3,qns4,qns5,qns6,qns7,qns8,qns9,qns10,qns11,qns12,qns13,qns_text1,qns_text2,qns_text3,lang)values "
		.$insert_txt;
		
		$params = array();
		$stmt = $this->sql->execute($query,$params);
		
		}catch(PDOException $e){
			$log = $e->getMessage();
            $this->logger->log($log);
		}
	
	
	
	}
	
	public function cschAction()
	{
		//csch컨트롤러에서 넘어왓다.
	}
	
	//중국어일시
	public function csconchAction()
	{
		$company = $this->request->getPost('company');
		$dept = $this->request->getPost('dept');
		$name = $this->request->getPost('name');
		$qns1 = $this->request->getPost('qns1');
		$qns2 = $this->request->getPost('qns2');
		$qns3 = $this->request->getPost('qns3');
		$qns4 = $this->request->getPost('qns4');
		$qns5 = $this->request->getPost('qns5');
		$qns6 = $this->request->getPost('qns6');
		$qns7 = $this->request->getPost('qns7');
		$qns8 = $this->request->getPost('qns8');
		$qns9 = $this->request->getPost('qns9');
		$qns10 = $this->request->getPost('qns10');
		$qns11 = $this->request->getPost('qns11');
		$qns12 = $this->request->getPost('qns12');
		$qns13 = $this->request->getPost('qns13');
		$qns_text1 = $this->request->getPost('qns_text1');
		$qns_text2 = $this->request->getPost('qns_text2');
		$qns_text3 = $this->request->getPost('qns_text3');
		$lang = "ch";
		
		try{
		$insert_txt = "('" .$company . "','" .$dept. "','" .$name. "',"
		.$qns1. "," .$qns2. "," .$qns3. "," .$qns4. "," .$qns5. "," .$qns6
		. "," .$qns7. "," .$qns8. "," .$qns9. "," .$qns10
		. "," .$qns11. "," .$qns12."," .$qns13.",'"
		.$qns_text1."','" .$qns_text2."','" .$qns_text3. "','" .$lang. "')";
		
		$query = "insert into mcssurvey(company,dept,name,qns1,qns2,qns3,qns4,qns5,qns6,qns7,qns8,qns9,qns10,qns11,qns12,qns13,qns_text1,qns_text2,qns_text3,lang)values "
		.$insert_txt;
		
		$params = array();
		$stmt = $this->sql->execute($query,$params);
		
		}catch(PDOException $e){
			$log = $e->getMessage();
            $this->logger->log($log);
		}
	
	
	
	}
	
	public function csvnAction()
	{
		//csjp컨트롤러에서 넘어왓다.
	}
	
	//일본어일시
	public function csconvnAction()
	{
		$company = $this->request->getPost('company');
		$dept = $this->request->getPost('dept');
		$name = $this->request->getPost('name');
		$qns1 = $this->request->getPost('qns1');
		$qns2 = $this->request->getPost('qns2');
		$qns3 = $this->request->getPost('qns3');
		$qns4 = $this->request->getPost('qns4');
		$qns5 = $this->request->getPost('qns5');
		$qns6 = $this->request->getPost('qns6');
		$qns7 = $this->request->getPost('qns7');
		$qns8 = $this->request->getPost('qns8');
		$qns9 = $this->request->getPost('qns9');
		$qns10 = $this->request->getPost('qns10');
		$qns11 = $this->request->getPost('qns11');
		$qns12 = $this->request->getPost('qns12');
		$qns13 = $this->request->getPost('qns13');
		$qns_text1 = $this->request->getPost('qns_text1');
		$qns_text2 = $this->request->getPost('qns_text2');
		$qns_text3 = $this->request->getPost('qns_text3');
		$lang = "vn";
		
		try{
		$insert_txt = "('" .$company . "','" .$dept. "','" .$name. "',"
		.$qns1. "," .$qns2. "," .$qns3. "," .$qns4. "," .$qns5. "," .$qns6
		. "," .$qns7. "," .$qns8. "," .$qns9. "," .$qns10
		. "," .$qns11. "," .$qns12."," .$qns13.",'"
		.$qns_text1."','" .$qns_text2."','" .$qns_text3. "','" .$lang. "')";
		
		$query = "insert into mcssurvey(company,dept,name,qns1,qns2,qns3,qns4,qns5,qns6,qns7,qns8,qns9,qns10,qns11,qns12,qns13,qns_text1,qns_text2,qns_text3,lang)values "
		.$insert_txt;
		
		$params = array();
		$stmt = $this->sql->execute($query,$params);
		
		}catch(PDOException $e){
			$log = $e->getMessage();
            $this->logger->log($log);
		}
	
	
	
	}
	
	public function csjpAction()
	{
		//csjp컨트롤러에서 넘어왓다.
	}
	
	//일본어일시
	public function csconjpAction()
	{
		$company = $this->request->getPost('company');
		$dept = $this->request->getPost('dept');
		$name = $this->request->getPost('name');
		$qns1 = $this->request->getPost('qns1');
		$qns2 = $this->request->getPost('qns2');
		$qns3 = $this->request->getPost('qns3');
		$qns4 = $this->request->getPost('qns4');
		$qns5 = $this->request->getPost('qns5');
		$qns6 = $this->request->getPost('qns6');
		$qns7 = $this->request->getPost('qns7');
		$qns8 = $this->request->getPost('qns8');
		$qns9 = $this->request->getPost('qns9');
		$qns10 = $this->request->getPost('qns10');
		$qns11 = $this->request->getPost('qns11');
		$qns12 = $this->request->getPost('qns12');
		$qns13 = $this->request->getPost('qns13');
		$qns_text1 = $this->request->getPost('qns_text1');
		$qns_text2 = $this->request->getPost('qns_text2');
		$qns_text3 = $this->request->getPost('qns_text3');
		$lang = "jp";
		
		try{
		$insert_txt = "('" .$company . "','" .$dept. "','" .$name. "',"
		.$qns1. "," .$qns2. "," .$qns3. "," .$qns4. "," .$qns5. "," .$qns6
		. "," .$qns7. "," .$qns8. "," .$qns9. "," .$qns10
		. "," .$qns11. "," .$qns12."," .$qns13.",'"
		.$qns_text1."','" .$qns_text2."','" .$qns_text3. "','" .$lang. "')";
		
		$query = "insert into mcssurvey(company,dept,name,qns1,qns2,qns3,qns4,qns5,qns6,qns7,qns8,qns9,qns10,qns11,qns12,qns13,qns_text1,qns_text2,qns_text3,lang)values "
		.$insert_txt;
		
		$params = array();
		$stmt = $this->sql->execute($query,$params);
		
		}catch(PDOException $e){
			$log = $e->getMessage();
            $this->logger->log($log);
		}
	
	
	
	}
	
	
	
	
	
	
	
	
	
	
	
}
?>