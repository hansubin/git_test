<?php
use Phalcon\Mvc\Controller;
use Phalcon\Tag;

class PopController extends Controller
{
	public static $dbid = 6;
	
	public function numberAction()
	{
		$id = $this->request->get('id');
		$this->view->setVar('id', $id);
	}
	
	public function cnameAction()
	{
		$sh = $this->request->get('sh');
		$sql = "select cst_alias from (select cst_alias,ltrim(replace(replace(cst_alias,'(주)',''),'㈜','')) as sort_name from xcstmst where cst_stat = '1' group by cst_alias) A where cst_alias ilike :sh order by sort_name";
		$params = array(':sh'=>'%'.$sh.'%');
		$stmt = $this->sql->execute($sql, $params, self::$dbid);
		$r_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$this->logger->log('rdata count:'.count($r_data));
		$id = $this->request->get('id');
		$this->view->setVar('id', $id);
		$this->view->setVar('sh', $sh);
		$this->view->setVar('data', $r_data);
		$this->view->setVar('title', '업체명입력');
		$this->assets->addCss('css/style.css?'.time());
	}
}