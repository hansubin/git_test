<?php
use Phalcon\Mvc\Controller;
use Phalcon\Tag;

class ReqoutController extends Controller
{
	public static $dbid = 6;//0->live,6->test
	
	public function indexAction()
	{
		$this->view->setVar('scale',1);
		$this->view->setVar('d_width',375);
		$this->assets->addJs('js/output.js?'.time());
		$this->assets->addJs('js/menu.js?'.time());
		$this->assets->addCss('css/style.css?'.time());
		$this->view->setVar('title','출고의뢰');
	}

	public function listAction()
	{
		//파라미터 해석
		$page = $this->request->get('page');
		if(isset($page)) {
			$itm_name = $this->session->get('itm_name');
			$itm_width = intval($this->session->get('itm_width'));
			$itm_length = intval($this->session->get('itm_length'));
			//거래처
			$cst_name = $this->session->get('cst_name');
		}
		else {
			$itm_name = $this->request->getPost('itm_name');
			if($itm_name == '상품명 폭 길이') $itm_name = '';
			$itm_arr = explode(' ',$itm_name);
			$tmp_cnt = count($itm_arr);
			$itm_width = 0;
			$itm_length = 0;
			if($tmp_cnt == 1) $itm_name = $itm_arr[0];
			else if($tmp_cnt < 3)
			{
				$itm_name = $itm_arr[0];
				$itm_width = intval($itm_arr[1]);
			}				
			else if($tmp_cnt < 4)
			{
				$itm_name = $itm_arr[0];
				$itm_width = intval($itm_arr[1]);
				$itm_length = intval($itm_arr[2]);
				//$this->logger->log('$itm_arr[1]:'.$itm_arr[1].',itm_width:'.$itm_width);
			}				
			
			//$this->logger->log('itm_name from post:'.$itm_name);
		}
		$this->session->set('itm_name',$itm_name);
		$this->session->set('itm_width',$itm_width);
		$this->session->set('itm_length',$itm_length);
		//거래처
			$cst_name = $this->request->getPost('cst_name');
			$this->session->set('cst_name',$cst_name);
		//패이지 정보
		if($page < 1) $page = 1;
		$maxList = 15;
		$maxPage = 7;
		$offset = ($page - 1) * $maxList;

		$where_add = '';
		if($itm_name > '') {
			$itm_name_var = $itm_name;
			$itm_name = "%".$itm_name."%";
			$where_name = " where itm_name ilike :itm_name ";
			$params = array(':itm_name'=>$itm_name,':offset'=>$offset,':limit'=>$maxList);
		}
		else{
			$where_name = '';
			$params = array(':offset'=>$offset,':limit'=>$maxList);
		}
		if($itm_width > 0)
		{
			$where_add .= ' and itm_width = :itm_width ';
			$params[':itm_width'] = $itm_width;
			$itm_name_var = $itm_name.' '.$itm_width;
		}
		if($itm_length > 0)
		{
			$where_add .= ' and itm_length = :itm_length ';
			$params[':itm_width'] = $itm_width;
			$params[':itm_length'] = $itm_length;
			$itm_name_var = $itm_name.' '.$itm_width.' '.$itm_length;
		}
		if($cst_name > '') {
			$params[':cst_alias'] = '%'.$cst_name.'%';
			if($itm_name > '') $where_add .= ' and cst_code ilike :cst_alias';
			else $where_add = ' where cst_code ilike :cst_alias';
		}
		$count = 0;
		try {
			$query = "select count(*) OVER() AS full_count,*from (select max(h.fac_code) as fac_code, substr(max(dispatch_dt), 1, 6) as dispatch_p1, substr(max(dispatch_dt), 7, 4) as dispatch_p2, max(b.cst_alias) as cst_name, max(c.itm_name) as itm_name_out, max(h.packing_no) as packing_no, max(f.emp_no) as emp_no, max(case when h.ship_date = '' then h.req_code else '-의뢰없음-' end) as req_code, max(case when h.ship_date = '' then e.emp_nm else '' end) as emp_nm, max(case when h.ship_date = '' then case when b.cst_alias > '' then b.cst_alias else h.cst_code end else case when h.cst_code > '' then i.cst_alias else '' end end) as cst_code, max(h.ship_id) as ship_id, max(h.ship_type) as ship_type, max(h.ship_emp) as ship_emp, max(h.ship_date) as ship_date, max(h.dispatch_dt) as dispatch_dt, h.itm_name as itm_name, h.itm_width as itm_width, h.itm_size as itm_size, h.itm_length as itm_length, sum(case when h.ship_date > '' then 0 else h.ship_qty end) as ord_qty, sum(case when h.ship_date > '' then h.ship_qty else 0 end) as ship_qty, max(h.remark) as remark, max(h.dst_code) as dst_code, sum(h.palette_qty) as palette_qty, sum(h.box_qty) as box_qty, max(h.up_excel) as up_excel, max(h.up_excel_ex1) as up_excel_ex1 from mSalesShipList h left join mSalesReqMst a on h.req_code = a.req_code left join mSalesOrdList c on a.ord_id = c.ord_id left join xCstMst d on c.cst_code = d.cst_code left join xCstMst i on h.cst_code = i.cst_code left join xEmpMst e on a.emp_no = e.emp_no left join xEmpMst f on d.emp_code = f.emp_no left join xCstMst b on b.cst_code = h.cst_code group by h.itm_size, h.itm_name, h.itm_width, h.itm_length order by h.itm_size, h.itm_name, h.itm_width, h.itm_length) A".$where_name.$where_add." order by packing_no, ship_date desc, dispatch_dt desc offset :offset limit :limit";
			$stmt = $this->sql->execute($query,$params,self::$dbid);
			$rdata = $stmt->fetchAll(PDO::FETCH_ASSOC);
			$count = intval($rdata[0]['full_count']);
			$this->logger->log(IndexController::pdo_sql_debug($query,$params));
			foreach ($rdata as $key => $value) {
				if($rdata[$key]['task_date'] > '') $rdata[$key]['task_date'] = substr($rdata[$key]['task_date'],4,2).'/'.substr($rdata[$key]['task_date'],-2);
				if($rdata[$key]['job_date'] > '') $rdata[$key]['job_date'] = substr($rdata[$key]['job_date'],4,2).'/'.substr($rdata[$key]['job_date'],-2);
				if($rdata[$key]['ship_date'] > '') $rdata[$key]['ship_date'] = substr($rdata[$key]['ship_date'],4,2).'/'.substr($rdata[$key]['ship_date'],-2);
			}
			$this->view->setVar('rdata',$rdata);
		} catch (PDOException $e) {
			$log = $e->getMessage();
			$this->logger->log($log);
			$this->view->setVar('c_data', '데이터가 없습니다.&#13;&#10;다시 시도해 주십시오.');
			$err = true;
		}
		$bottom = PageController::bottom(array('maxList'=>$maxList,'maxPage'=>$maxPage,'cPage'=>$page,'totCount'=>$count,'link'=>'reqout/list','font_size'=>20,'fix_color'=>'#000000','link_color'=>'#00aeff',));
		$this->view->setVar('scale',1);
		$this->view->setVar('d_width',375);
		$this->view->setVar('bottom',$bottom);
		$this->view->setVar('itm_name',$itm_name_var);
		$this->view->setVar('cst_name',$cst_name);
		$this->assets->addJs('js/output.js?'.time());
		$this->assets->addJs('js/menu.js?'.time());
		$this->assets->addCss('css/style.css?'.time());
		$this->view->setVar('title','출고의뢰');
	}
}
?>