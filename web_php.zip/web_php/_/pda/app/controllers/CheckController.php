<?php

use Phalcon\Mvc\Controller;
use Phalcon\Tag;

class CheckController extends Controller
{
	public static $dbid = 6;//0->live,6->test
	public static $chk_arr = array("","출고","숙성","이동","실사","패킹");
	private static $chk_id = 4;
	
	public function indexAction()
	{
		$this->session->set('o_data',NULL);
		$this->session->set('b_cods',NULL);
		include 'view_basic.php';
	}

	public function cancelAction()
	{
		$i_ids = $this->session->get('i_ids');
		if($stmt = $this->sql->execute("delete from mInvTakeStock where take_id in(".$i_ids.")")){
			$user = $this->session->get('user');
			$f_data = array();
			$f_arr = ['','1공장','2공장','3공장','4공장','5공장','오창공장'];
			for($i = 1; $i <= 6; $i++)
			{
				//예외 공장 처리
				if($i == 2 or $i == 4) continue;
				$offset = $i - 1;
				$f_data[$offset]['key'] = '00'.(string)$i;
				$f_data[$offset]['val'] = $f_arr[$i];
				if($user['fac'] == '00'.(string)$i) $f_data[$offset]['chk'] = "selected = 'selected'";
				else $f_data[$offset]['chk'] = '';
			}
			$j_data = array();
			if(date('d') < '16') $tmp_date = date('Ymd',strtotime(date('Ymd').' -1 months'));
			else $tmp_date = date('Ymd');
			//$this->logger->log('tmp_date:'.$tmp_date);
			$max_list = 3;
			for($i = 0; $i < $max_list; $i++)
			{
				$offset = $i - $max_list + 1;
				$j_data[$i]['val'] = date('Ym',strtotime($tmp_date . ' '.$offset.' months'));
				$j_data[$i]['key'] = substr($j_data[$i]['val'],2);
				if($i == $max_list - 1)$j_data[$i]['chk'] = "selected = 'selected'";
				else $j_data[$i]['chk'] = '';
			}
			$err = false;
			//Add some local CSS resources
			$this->view->setVar('jdata',$j_data);
			$this->view->setVar('fdata',$f_data);
			//취소리스트로 리스트를 만들어 보여주어야 함
			$data = $this->session->get('o_data');
			$this->session->set('b_cods','');
			$this->view->setVar('data',$data);
		}
		else {
			$err = true;
			$this->view->setVar('c_data','기록을 취소하지 못했습니다.&#13;&#10;다시 시도해 주십시오.');
		}
		$this->view->setVar('err',$err);
		include 'view_basic.php';
	}
	
	public function recordAction()
	{
		$data = $this->session->get('o_data');
		$user = $this->session->get('user');
		//작업일과 작업장 읽기
		$g_data = $this->request->getPost();
		$p_data = array();
		foreach($g_data as $key => $value){
			$p_data[$key] = explode(',',$g_data[$key]);
			$this->logger->log('g_data['.$key.']:'.$g_data[$key][0]);
		}
		$job_month = '20'.$p_data[0][0];
		$fac_code = $p_data[1][0];
		//this->tag->setDoctype(Tag::HTML401_STRICT);
		$insert_txt = '';
		$b_cod_arr = array();
		$b_cods = $this->session->get('b_cods');
		foreach($data as $key => $value)
		{
    //$this->logger->log('itm_ucode['.$key.']:'.$data[$key]['itm_ucode']);
			$b_cod = $data[$key]['req_code'].$data[$key]['req_seq'];
			$stmt = $this->sql->execute("select take_id from mInvTakeStock where req_code = :b_cod and req_seq = :b_seq"
                , array('b_cod' => $data[$key]['req_code'], 'b_seq' => $data[$key]['req_seq']), self::$dbid);
            $o_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if (count($o_data) == 0) {
				if(isset($data[$key]['itm_width'])) $tmp_width = $data[$key]['itm_width'];
				else $tmp_width = 0;
				if(isset($data[$key]['itm_width2'])) $tmp_width2 = $data[$key]['itm_width2'];
				else $tmp_width2 = 0;
				if(isset($data[$key]['itm_length'])) $tmp_length = $data[$key]['itm_length'];
				else $tmp_length = 0;
				if(isset($data[$key]['itm_ea'])) $tmp_ea = $data[$key]['itm_ea'];
				else $tmp_ea = 0;
				if(isset($data[$key]['qty'])) $tmp_qty = $data[$key]['qty'];
				else $tmp_qty = 0;
				$insert_txt .= "('".$data[$key]['type_name']."','".$data[$key]['itm_name']."',".$tmp_width.",".$tmp_width2.",".$tmp_length.",'".$data[$key]['itm_thic']."','".$data[$key]['rip_code']."','".$data[$key]['itm_ucode']."','".$data[$key]['lot_no']."','".$data[$key]['req_code']."','".$data[$key]['req_seq']."','".$job_month."','".$fac_code."','".$user['pda_id']."',current_timestamp,'".$data[$key]['itm_code']."','A','".$data[$key]['itm_etc']."','".$data[$key]['itm_iunit']."',".$tmp_ea.",".$tmp_qty.",'".$data[$key]['cst_code']."','".$data[$key]['cst_name']."','".$data[$key]['task_date']."'),";
			}
		}
		if(strlen($insert_txt) > 0)
		{
			$insert_txt = substr($insert_txt,0,-1);
			$sql = "insert into mInvTakeStock(type_name,itm_name,itm_width,itm_width2,itm_length,itm_thic,rip_code,itm_ucode,lot_no,req_code,req_seq,job_month,fac_code,insert_emp,insert_dt, itm_code,itm_quality,itm_etc,itm_iunit,itm_ea,itm_qty,cst_code,cst_name,stock_date) values".$insert_txt.' returning take_id';
			$this->logger->log('insert sql:'.$sql);
			if($stmt = $this->sql->execute($sql)){
				$insert_ids = $stmt->fetchAll(PDO::FETCH_NUM);
				$i_ids = str_replace(array("]","["),"",json_encode($insert_ids));
				$this->session->set('i_ids',$i_ids);
				$this->session->set('b_cods',$b_cod_arr);
				$this->view->setVar('c_data','기록되었습니다.&#13;&#10;기록된 리스트는 다음과 같습니다.');
				$this->view->setVar('data',$data);
				$err = false;
			}
			else{
				$this->view->setVar('c_data','데이터 베이스 기록에 실패하였습니다.&#13;&#10;다시 시도해 주십시오.');
				$err = true;
			}
		}
		else{
			$this->view->setVar('c_data','선택된 리스트가 없거나 이미 기록한 바코드입니다.');
			$err = true;
		}
		$this->view->setVar('err',$err);
		include 'view_basic.php';
	}
	//바코드를 읽어 바코드에 해당하는 품목들을 불러들인다.
	public function listAction()
	{
		$err = false;
		//this->tag->setDoctype(Tag::HTML401_STRICT);
		$b_id = strtoupper($this->request->getPost('b_id'));
		$b_cod = substr($b_id, 0, -2);
		$b_seq = substr($b_id, -2);
		//지우기 처리
		$del_key = $this->request->getPost('del');
		//$this->logger->log('del_key:'.$del_key);
		if(strlen($del_key) == 8)
		{
			$data = $this->session->get('o_data');
			foreach($data as $key => $value) {
				if($del_key == $data[$key]['req_code'].$data[$key]['req_seq'])
				{
					unset($data[$key]);
					$this->session->set('o_data',$data);
					break;
				}
			}
		}
		$stmt = $this->sql->execute("select req_code from mInvTakeStock where req_code = :b_cod and req_seq = :b_seq"
			   ,array('b_cod'=>$b_cod,'b_seq'=>$b_seq),self::$dbid);
		$check = $stmt->fetchAll(PDO::FETCH_ASSOC);
		  if(count($check) == 0)
		{
			if(isset($b_id)){
			try {
			//job_month,itm_quality,itm_iunit
			$sql = "select a.req_code,a.req_seq,c.type_name,case when b.itm_code is null and a.task_part > '1' then d.itm_code else a.itm_code end as itm_code,case when b.itm_code is null and a.task_part > '1' then d.itm_name else b.itm_name end as itm_name,a.itm_width,a.itm_length,b.itm_iunit,b.itm_width2,b.itm_thic,b.itm_ucode,b.itm_type as itm_etc,b.rip_code,a.itm_ea,a.equ_code,a.lot_no,a.cst_code,a.cst_name,a.qty,a.task_date from mBcodHis a left join mTaskListMst d on a.bcod_id = d.task_id left join mItmMst b on a.itm_code = b.itm_code left join xItmType c on b.itm_type2 = c.type_code where a.req_code = :b_cod and a.req_seq = :b_seq order by a.req_code,a.req_seq";
			$params = array(':b_cod'=>$b_cod,':b_seq'=>$b_seq);
			$stmt = $this->sql->execute($sql,$params,self::$dbid);
			$this->logger->log('log'.IndexController::pdo_sql_debug($sql,$params));
			$o_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
			if(count($o_data) == 0){
				$data = '바코드에 해당하는 기록이 없거나 잘못된 바코드입니다.&#13;&#10;다시 읽어주세요.&#13;&#10;ex)170526S0601';
				$err = true;
			}
			else{
				$same_bid = false;
				$data = $this->session->get('o_data');
				if (is_array($data) || is_object($data)){
					foreach($data as $key => $value) {
						if($b_id == $data[$key]['req_code'].$data[$key]['req_seq']) $same_bid = true;
					}
					if($same_bid == false){
						foreach ($o_data as $key => $value) {
							$data[] = $o_data[$key];
						}
					}
				}
				else{
					$data = $o_data;
				}
				foreach($data as $key => $value)
				{
					$data[$key]['size'] = $data[$key]['req_code'].$data[$key]['req_seq'];
					$data[$key]['post'] = "post('/check/list',{'del':'".$data[$key]['req_code'].$data[$key]['req_seq']."'});";
				}
				$this->session->set('o_data',$data);
			}
		} catch (PDOException $e) {
			$log = $e->getMessage();
			$this->logger->log($log);
			$this->view->setVar('c_data', '데이터 베이스 기록에 실패하였습니다.&#13;&#10;다시 시도해 주십시오.');
			$this->view->setVar('data', '');
			$err = true;
		}
		}
		else{
			$data = '박스라벨의 바코드를 입력해주세요 ex)170526S0601';
			$err = true;
		}
	}
	else
	{
		$data = '이미 기록된 바코드입니다';
			$err = true;
	}
		$user = $this->session->get('user');
		$f_data = array();
		$f_arr = ['','1공장','2공장','3공장','4공장','5공장','오창공장'];
		for($i = 1; $i <= 6; $i++)
		{
			//예외 공장 처리
			if($i == 2 or $i == 4) continue;
			$offset = $i - 1;
			$f_data[$offset]['key'] = '00'.(string)$i;
			$f_data[$offset]['val'] = $f_arr[$i];
			if($user['fac'] == '00'.(string)$i) $f_data[$offset]['chk'] = "selected = 'selected'";
			else $f_data[$offset]['chk'] = '';
		}
		$j_data = array();
		if(date('d') < '16') $tmp_date = date('Ymd',strtotime(date('Ymd').' -1 months'));
		else $tmp_date = date('Ymd');
		//$this->logger->log('tmp_date:'.$tmp_date);
		$max_list = 3;
		for($i = 0; $i < $max_list; $i++)
		{
			$offset = $i - $max_list + 1;
			$j_data[$i]['val'] = date('Ym',strtotime($tmp_date . ' '.$offset.' months'));
			$j_data[$i]['key'] = substr($j_data[$i]['val'],2);
			if($i == $max_list - 1)$j_data[$i]['chk'] = "selected = 'selected'";
			else $j_data[$i]['chk'] = '';
		}
		
		//Add some local CSS resources
		$this->view->setVar('jdata',$j_data);
		$this->view->setVar('fdata',$f_data);
		$this->view->setVar('data',$data);
		$this->view->setVar('err',$err);
		$this->view->setVar('today',date('Y-m-d'));
		include 'view_basic.php';
	}
}