<html>
	<?= $this->partial('partials/header') ?>
	<body>
	<script>
	document.body.ontouchend = function() { document.querySelector('[name="b_id"]').focus(); };
	</script>
	<?= $this->tag->form(['pack/list', 'method' => 'post']) ?>
	<?= $this->partial('partials/body1') ?>
	<table width=<?= $d_width ?> bgcolor = "#30508C" style="color:white;">
            <tr>
                    <td align='center'>패킹리스트 작성</td>
            </tr>
	</table>
	<?= $this->tag->hiddenField([$this->security->getTokenKey(), 'value' => $this->security->getToken()]) ?>
	<?= $this->tag->endform() ?>
	</body>
</html>
