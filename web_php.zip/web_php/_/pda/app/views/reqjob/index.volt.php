<html>
	<?= $this->partial('partials/header') ?>
	<body onload="document.getElementById('i_id').focus();">
	<table width=<?= $d_width ?> bgcolor="gray" cellspacing = "0" cellpadding = "0">
		<tr>
			<td align="center" width ="3%"><img src="/pda/img/list.png" onClick="redirectUser(10)"/></td>
			<td align="center" width ="20%"><h2><?= $title ?></h2></td>
			<td width ="3%" align="right"><?= $this->tag->image(['/pda/img/home.png', false]) ?></td>
			<td width ="12%" align="right">품목</td>
			<form action="reqjob/list" id="g_form" method="POST">
			<td width="30%"><input type = 'text' name = 'itm_name' size = '17' id = 'i_id' value = '상품명 폭 길이' style='text-transform:uppercase' onClick = "clearInput('i_id')" onKeyPress = "if(event.keyCode==13) { document.getElementById('g_form').submit(); return false; }" /></td>
			<td width ="15%" align="right">거래처</td>
			<td width="20%"><input type = 'text' name = 'cst_name' size = '10' id = 'c_id' style='text-transform:uppercase' onClick = "clearInput('c_id')" onKeyPress = "if(event.keyCode==13) { document.getElementById('g_form').submit(); return false; }" /></td>
			</form>
		</tr>
	</table>
	<table width=<?= $d_width ?> bgcolor="#B0C4DE">
		<tr bgcolor="#B0C4DE">
			<td align="center">거래처</td>
			<td align="center">상품명</td>
			<td align="center">폭/길이</td>
			<td align="center">수량</td>
			<td align="center">지시일</td>
			<td align="center">입고일</td>
			<td align="center">출고일</td>
			<td align="center">출고량</td>
		</tr>
	</table>
	<?= $this->tag->hiddenField([$this->security->getTokenKey(), 'value' => $this->security->getToken()]) ?>
	</body>
</html>