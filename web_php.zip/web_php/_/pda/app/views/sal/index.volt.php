<html>
	<?= $this->partial('partials/header') ?>
	<body onload="document.getElementById('b_id').focus();">
	<?= $this->tag->form(['sal/list', 'method' => 'post']) ?>
	<table width=<?= $d_width ?> bgcolor="gray" cellspacing = "0" cellpadding = "0">
	<tr>
		<td align="center" width ="10%"><img src="/pda/img/list.png" onClick="redirectUser(10)"/></td>
		<td align="center" width ="32%"><h2><?= $title ?></h2></td>
		<td width ="8%" align="right"><?= $this->tag->image(['/pda/img/home.png', false]) ?></td>
		<td width="50%"><input type = 'text' name = 'itm_name' size = '17' id = 'b_id' value = '상품명 폭 길이' style='text-transform:uppercase' onClick = 'clearInput()' onKeyPress = "if(event.keyCode==13) { document.getElementById('b_id').submit(); return false; }" /></td>
	</tr>
	</table>
	<table width=<?= $d_width ?> bgcolor="#B0C4DE">
		<tr bgcolor="#B0C4DE">
			<td align="center">상품명</td>
			<td align="center">폭/길이/수량</td>
			<td align="center">취소</td>
		</tr>
	</table>
	<?= $this->tag->hiddenField([$this->security->getTokenKey(), 'value' => $this->security->getToken()]) ?>
	<?= $this->tag->endform() ?>
	</body>
</html>