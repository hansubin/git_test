<html>
	<?= $this->partial('partials/header') ?>
	<body onload="document.getElementById('b_id').focus();">
	<?= $this->tag->form(['sal/list', 'method' => 'post']) ?>
	<table width=<?= $d_width ?> bgcolor="gray" cellspacing = "0" cellpadding = "0">
		<tr>
			<td align="center" width ="10%"><img src="/pda/img/list.png" onClick="redirectUser(10)"/></td>
			<td align="center" width ="32%"><h2><?= $title ?></h2></td>
			<td width ="8%" align="right"><?= $this->tag->image(['/pda/img/home.png', false]) ?></td>
			<td width="50%"><input type = 'text' name = 'itm_name' size = '17' id = 'b_id' style='text-transform:uppercase' onClick = "clearInput('b_id')" onKeyPress = "if(event.keyCode==13) { document.getElementById('b_id').submit(); return false; }" /></td>
		</tr>
	</table>
	<table width=<?= $d_width ?>>
		<tr bgcolor="#B0C4DE">
			<td align="center">상품명</td>
			<td align="center">폭/길이</td>
			<td align="center">수량</td>
		</tr>
		<?php if (!(empty($rdata))) { ?>
		<?php foreach ($rdata as $rt) { ?>
		<tr>
			<td align='left'><?= $rt['itm_name'] ?></td>
			<td align='left'>[<?= $rt['itm_width'] ?>/<?= $rt['itm_length'] ?>]</td>
			<td align='center'><?= $rt['itm_ea'] ?></td>
		</tr>
		<?php } ?>  
		<tr>
			<td colspan = '3' align='center'><?= $bottom ?></td>
		</tr>
    <?php } ?>
	</table>
	<?= $this->tag->hiddenField([$this->security->getTokenKey(), 'value' => $this->security->getToken()]) ?>
	<?= $this->tag->endform() ?>
	</body>
</html>