<html>
	<?= $this->partial('partials/header') ?>
	<body onload="document.getElementById('i_id').focus();">
	<table width=<?= $d_width ?> bgcolor="gray" cellspacing = "0" cellpadding = "0">
		<tr>
			<td align="center" width ="5%"><img src="/pda/img/list.png" onClick="redirectUser(10)"/></td>
			<td align="center" width ="18%"><h2><?= $title ?></h2></td>
			<td width ="5%" align="right"><?= $this->tag->image(['/pda/img/home.png', false]) ?></td>
			<td width ="10%" align="right">품목</td>
			<form action="../reqout/list" id="g_form" method="POST">
			<td width="30%"><input type = 'text' name = 'itm_name' size = '15' id = 'i_id' value='<?= $itm_name ?>' style='text-transform:uppercase' onClick = "clearInput('i_id')" onKeyPress = "if(event.keyCode==13) { document.getElementById('g_form').submit(); return false; }" /></td>
			<td width ="12%" align="right">거래처</td>
			<td width="20%"><input type = 'text' name = 'cst_name' size = '10' id = 'c_id' value='<?= $cst_name ?>' style='text-transform:uppercase' onClick = "clearInput('c_id')" onKeyPress = "if(event.keyCode==13) { document.getElementById('g_form').submit(); return false; }" /></td>
			</form>
		</tr>
	</table>
	<table width=<?= $d_width ?>>
		<tr bgcolor="#B0C4DE">
			<td align="center">거래처</td>
			<td align="center">상품명</td>
			<td align="center">폭/길이</td>
			<td align="center">수량</td>
			<td align="center">파레트</td>
			<td align="center">박스</td>
			<td align="center">출고일</td>
			<td align="center">출고량</td>
		</tr>
		<?php if (!(empty($rdata))) { ?>
		<?php foreach ($rdata as $rt) { ?>
		<tr>
			<td align='left'><?= $rt['cst_name'] ?></td>
			<td align='left'><?= $rt['itm_name'] ?></td>
			<td align='left'><?= $rt['itm_width'] ?>/<?= $rt['itm_length'] ?></td>
			<td align='center'><?= $rt['ord_qty'] ?></td>
			<td align='center'><?= $rt['palette_qty'] ?></td>
			<td align='center'><?= $rt['box_qty'] ?></td>
			<td align='center'><?= $rt['ship_date'] ?></td>
			<td align='center'><?= $rt['ship_qty'] ?></td>
		</tr>
		<?php } ?>
	<?php } ?>
	</table>
	<table width=<?= $d_width ?>>
		<tr>
			<td align='center'><?= $bottom ?></td>
		</tr>
	</table>
	<?= $this->tag->hiddenField([$this->security->getTokenKey(), 'value' => $this->security->getToken()]) ?>
	</body>
</html>