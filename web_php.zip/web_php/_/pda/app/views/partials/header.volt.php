<head>
	<title><?= $title ?></title>
	<meta name="viewport" content="user-scalable=no, initial-scale=<?= $scale ?>, maximum-scale=<?= $scale ?>, minimum-scale=<?= $scale ?>, width=<?= $d_width ?>">
	<?= $this->assets->outputCss() ?>
	<?= $this->assets->outputJs() ?>
</head>