<html>
	<?= $this->partial('partials/header') ?>
	<body>
	<?= $this->tag->form(['check/list', 'method' => 'post']) ?>
	<?= $this->partial('partials/body1') ?>
	<table width=<?= $d_width ?>>
		<tr>
			<td align='center'>
				<select name="job_month">
				<?php foreach ($jdata as $jm) { ?>
					<option value="<?= $jm['key'] ?>" <?= $jm['chk'] ?>><?= $jm['val'] ?></option>
				<?php } ?>
				</select>
			</td>
			<td align='center'>
				<select name="fac">
				<?php foreach ($fdata as $fc) { ?>
					<option value="<?= $fc['key'] ?>" <?= $fc['chk'] ?>><?= $fc['val'] ?></option>
				<?php } ?>
				</select>
			</td>
				<td align='center'><input type="button" name="o_btn" value="실사" onclick="arrPost2('/check/record','job_month','fac')" /></td>
			<td align='center'><input type="button" name="o_btn" value="취소" onclick="selectedMove('/check')" /></td>
		</tr>
	</table>
	<table width=<?= $d_width ?>>
	<?php if ($err == true) { ?>
		<tr>
			<td><?= $this->tag->textArea(['comment', 'value' => $data, 'cols' => 25, 'rows' => 6, 'readonly' => 'readonly', 'style' => 'width:100%']) ?></td>
		</tr>
	<?php } else { ?>
		<tr bgcolor="#B0C4DE">
			<td align="center">업체</td>
			<td align="center" colspan = 2>가공일</td>
			
			</tr>
		<tr bgcolor="#B0C4DE">
			<td align="center">품명[폭/길이]</td>
			<td align="center">수량</td>
			<td align="center">취소</td>
		</tr>
		<?php foreach ($data as $dt) { ?>
			<tr>
				<td align="center"><?= $dt['cst_name'] ?></td>
				<td align="center" colspan = 2><?= $dt['task_date'] ?></td>
			</tr>
			<tr>
				<td align="center"><?= $dt['itm_name'] ?>[<?= $dt['itm_width'] ?>/<?= $dt['itm_length'] ?>]</td>
				<td align="center"><input type="text" name="size[]" size = "4" value = "<?= $dt['itm_ea'] ?>" /></td>
				<td align="center"><input type="button" name="del" value='Del' onclick="<?= $dt['post'] ?>" /></td>
			</tr>
		<?php } ?>
	</table>
	<table width=<?= $d_width ?>>
		<tr>
			<td align='center'>
				<select name="job_month">
				<?php foreach ($jdata as $jm) { ?>
					<option value="<?= $jm['key'] ?>" <?= $jm['chk'] ?>><?= $jm['val'] ?></option>
				<?php } ?>
				</select>
			</td>
			<td align='center'>
				<select name="fac">
				<?php foreach ($fdata as $fc) { ?>
					<option value="<?= $fc['key'] ?>" <?= $fc['chk'] ?>><?= $fc['val'] ?></option>
				<?php } ?>
				</select>
			</td>
				<td align='center'><input type="button" name="o_btn" value="실사" onclick="arrPost2('/check/record','job_month','fac')" /></td>
			<td align='center'><input type="button" name="o_btn" value="취소" onclick="selectedMove('/check')" /></td>
		</tr>
	</table>
	<?php } ?>
	<?= $this->tag->hiddenField([$this->security->getTokenKey(), 'value' => $this->security->getToken()]) ?>
	<?= $this->tag->endform() ?>
	</body>
</html>
