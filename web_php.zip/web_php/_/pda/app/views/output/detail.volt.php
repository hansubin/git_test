<html>
	<?= $this->partial('partials/header') ?>
	<body>
	<?= $this->tag->form(['output/detail', 'method' => 'post']) ?>
	<table width=<?= $d_width ?> bgcolor="gray" cellspacing = "0" cellpadding = "0">
		<tr>
			<td align="center" width ="10%"><img src="/pda/img/list2.png" onClick="redirectUser(10)"/></td>
			<td align="center" width ="32%"><h2><?= $title ?></h2></td>
			<td width ="8%" align="right"><?= $this->tag->image(['/pda/img/home.png', false]) ?></td>
		</tr>
	</table>
	<table width=<?= $d_width ?> cellspacing = "0" cellpadding = "0">
	<tr>
		<td><input type="radio" name="work" value="O" onClick="redirectUser(1)" <?= $w_chk1 ?> />출고</td>
		<td><input type="radio" name="work" value="A" onClick="redirectUser(2)" <?= $w_chk2 ?> />숙성</td>
		<td><input type="radio" name="work" value="M" onClick="redirectUser(3)" <?= $w_chk3 ?> />이동</td>
		<td><input type="radio" name="work" value="C" onClick="redirectUser(4)" <?= $w_chk4 ?> />실사</td>
		<td><input type="radio" name="work" value="C" onClick="redirectUser(5)" <?= $w_chk5 ?> />패킹</td>
	</tr>
	</table>
	<table width=<?= $d_width ?>>
		<tr>
			<td align='right'>
				<select name="fac">
				<?php foreach ($fdata as $fc) { ?>
					<option value="<?= $fc['key'] ?>" <?= $fc['chk'] ?>><?= $fc['val'] ?></option>
				<?php } ?>
				</select>
			</td>
			<td align='left' ><input type='submit' value='로 변경'/></td>
		</tr>
	</table>
	<table width=<?= $d_width ?>>
		<tr bgcolor="#B0C4DE">
			<td align="center">상품명</td>
			<td align="center">폭/길이</td>
			<td align="center">의뢰</td>
			<td align="center">출고</td>
		</tr>
		<tr bgcolor="#B0C4DE">
			<td align="center">업체명</td>
			<td align="center">담당</td>
			<td align="center">출발</td>
			<td align="center">도착</td>
		</tr>
		<?php if (!(empty($rdata))) { ?>
		<?php foreach ($rdata as $rt) { ?>
		<tr>
			<td align='left'><?= $rt['itm_name'] ?></td>
			<td align='left'>[<?= $rt['itm_width'] ?>/<?= $rt['itm_length'] ?>]</td>
			<td align='center'><?= $rt['ord_qty'] ?></td>
			<td align='center'><?= $rt['ship_qty'] ?></td>
		</tr>
		<tr>
			<td align='left'><?= $rt['cst_name'] ?></td>
			<td align='left'><?= $rt['emp_nm'] ?></td>
			<td align='center'><?= $rt['fac_code'] ?></td>
			<td align='center'><?= $rt['dst_code'] ?></td>
		</tr>
		<tr><td colspan='4'><hr></td></tr>
		<?php } ?>  
		<tr>
			<td colspan = '3' align='center'><?= $bottom ?></td>
		</tr>
    <?php } ?>
	</table>
	<?= $this->tag->hiddenField([$this->security->getTokenKey(), 'value' => $this->security->getToken()]) ?>
	<?= $this->tag->endform() ?>
	</body>
</html>