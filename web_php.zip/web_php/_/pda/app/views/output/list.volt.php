<html>
	<?= $this->partial('partials/header') ?>
	<body>
	<script>
		var openWin;
		function openChild(cname)
		{
			window.open(cname,"childForm", "width=200, height=300, resizable = no, scrollbars = yes");
		}
	</script>
	<?= $this->tag->form(['output/list', 'method' => 'post']) ?>
	<?= $this->partial('partials/body1') ?>
	<table width=<?= $d_width ?>>
		<tr bgcolor="#B0C4DE">
			<td align="center">업체명</td>
			<td align="center">품명[폭/길이]</td>
			<td align="center">수량</td>
		</tr>       
    <?php if (!(empty($rdata))) { ?>
		<?php foreach ($rdata as $rt) { ?>
		<tr>
			<td align="center" id = "T*<?= $rt['req_code'] ?>" onclick="openChild('../pop/cname?id=<?= $rt['req_code'] ?>');"><?= $rt['cst_name'] ?></td>
			<td align='center'><?= $rt['itm_name'] ?>[<?= $rt['itm_width'] ?>/<?= $rt['itm_length'] ?>]</td>
			<td>
				<input type='hidden' id = "C*<?= $rt['req_code'] ?>" name = 'c_name' value=<?= $dt['cst_name'] ?>>
				<input style="width: 30px;" type='text' id="<?= $rt['req_code'] ?>" size='4' name='o_qty' value="<?= $rt['ord_qty'] ?>" onclick="openChild('../pop/number?id=<?= $rt['req_code'] ?>');">
			</td>
		</tr>
		<?php } ?>  
    <?php } ?>
		<input type="submit" style="position: absolute; left: -9999px; width: 1px; height: 1px;"/>
	</table>
	<?php if ($err == true) { ?>
	<table width=<?= $d_width ?>>
		<tr>
			<td colspan="4"><?= $this->tag->textArea(['comment', 'value' => $err_msg, 'cols' => 25, 'rows' => 6, 'readonly' => 'readonly', 'style' => 'width:100%']) ?></td>
		</tr>
		<tr bgcolor="#B0C4DE">
			<td align="center">업체</td>
			<td align="center">품명[폭/길이]</td>
			<td align="center">수량</td>
			<td align="center">취소</td>
		</tr>	      
	</table>
	<?php } ?>
	<table width=<?= $d_width ?>>
		<tr>
			<td align='center'><input type="button" name="o_btn" value="출고" onclick="arrPost2('/output/record','c_name','o_qty')" /></td>
			<td align='center'><input type="button" name="o_btn" value="샘플출고" onclick="arrPost2('/output/srecord','c_name','o_qty')" /></td>
			<td align='center'><input type="button" name="o_btn" value="취소" onclick="post('/output')" /></td>
		</tr>
	</table>
	<table width=<?= $d_width ?>>
		<tr bgcolor="#B0C4DE">
			<td align="center">업체</td>
			<td align="center">품명[폭/길이]</td>
			<td align="center">수량</td>
			<td align="center">취소</td>
		</tr>
		<?php if ($d_cnt > 0) { ?>     
			<?php foreach ($data as $dt) { ?>
				<tr>
					<td align="center" id = "T*<?= $dt['id'] ?>" onclick="openChild('../pop/cname?id=<?= $dt['id'] ?>');"><?= $dt['cst_name'] ?></td>
					<td align='center'><?= $dt['itm_name'] ?>[<?= $dt['itm_width'] ?>/<?= $dt['itm_length'] ?>]</td>
					<td>
						<input type='hidden' id = "C*<?= $dt['id'] ?>" name = 'c_name' value=<?= $dt['cst_name'] ?>>
						<input style="width: 30px;" type='text' id="<?= $dt['id'] ?>" size='4' name='o_qty' value="<?= $dt['itm_ea'] ?>" onclick="openChild('../pop/number?id=<?= $dt['id'] ?>');">
					</td>
					<td align="center"><input type="button" name="del" value='Del' onclick="<?= $dt['post'] ?>" /></td>
				</tr>
			<?php } ?>   
		<?php } else { ?>
				<tr>
					<td align="center" colspan = "4">박스라벨의 바코드를 읽지 않고 출고하면 의뢰코드의 상품이 출고된 것으로 처리됩니다.</td>
				</tr>
		<?php } ?>
	</table>
	<table width=<?= $d_width ?>>
		<tr>
			<td align='center'><input type="button" name="o_btn" value="출고" onclick="arrPost2('/output/record','c_name','o_qty')" /></td>
			<td align='center'><input type="button" name="o_btn" value="샘플출고" onclick="arrPost2('/output/srecord','c_name','o_qty')" /></td>
			<td align='center'><input type="button" name="o_btn" value="취소" onclick="post('/output')" /></td>
		</tr>
	</table>
	<?= $this->tag->hiddenField([$this->security->getTokenKey(), 'value' => $this->security->getToken()]) ?>
	<?= $this->tag->endform() ?>
	</body>
</html>
