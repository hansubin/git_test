<!DOCTYPE html>
<html>
	<?= $this->partial('partials/header') ?>
	<script type="text/javascript">
		function increase_num(id,num){
			var el = document.getElementById(id);
			el.value = el.value - 0 + 1 * num;
		}

		function decrease_num(id,num){
			var el = document.getElementById(id);
			el.value -= 1 * num;
		}
		
		function getParentText(){
			document.getElementById("cInput").value = opener.document.getElementById("<?= $id ?>").value;
		}
		
		function setParentText(){
			opener.document.getElementById("<?= $id ?>").value = document.getElementById("cInput").value;
		}
	</script>
<body onload = "getParentText();">
	<br>
	<div align = 'center'><b><font size="5" color="gray">수치 입력</font></b></div>
	<br><br>
	<table align = 'center'>
		<tr>
			<td><input type="button" name="n_btn" size='1' value="▲" onclick="increase_num('cInput',1000)" /></td>
			<td><input type="button" name="n_btn" size='1' value="▲" onclick="increase_num('cInput',100)" /></td>
			<td><input type="button" name="n_btn" size='1' value="▲" onclick="increase_num('cInput',10)" />
			</td>
			<td><input type="button" name="n_btn" size='1' value="▲" onclick="increase_num('cInput',1)" /></td>
		</tr>
		<tr>
			<td colspan = '4' align = 'center'>
				<input type="text" id="cInput" size='4' onkeydown='return onlyNumber(event)' onkeyup='removeChar(event)' style='ime-mode:disabled;'>
			</td>
		</tr>
		<tr>
			<td><input type="button" name="n_btn" size='1' value="▼" onclick="decrease_num('cInput',1000)" /></td>
			<td><input type="button" name="n_btn" size='1' value="▼" onclick="decrease_num('cInput',100)" /></td>
			<td><input type="button" name="n_btn" size='1' value="▼" onclick="decrease_num('cInput',10)" /></td>
			<td><input type="button" name="n_btn" size='1' value="▼" onclick="decrease_num('cInput',1)" /></td>
		</tr>
	</table>
	<br><br>
	<div align = 'center'><input type="button" value="확인" onclick="setParentText();window.close()"></div>
</body>
</html>