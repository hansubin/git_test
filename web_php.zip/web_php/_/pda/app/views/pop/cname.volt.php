<!DOCTYPE html>
<html>
	<?= $this->partial('partials/header') ?>
	<script type="text/javascript">
		function getParentText(){
			if('<?= $sh ?>' == '') document.getElementById("cInput").value = opener.document.getElementById("C*<?= $id ?>").value;
			else document.getElementById("cInput").value = '<?= $sh ?>';
		}
		
		function setParentText(){
			opener.document.getElementById("T*<?= $id ?>").innerHTML = document.getElementById("cInput").value;
			opener.document.getElementById("C*<?= $id ?>").value = document.getElementById("cInput").value;
		}
		function setInputTextFromList(cst_name){
			document.getElementById("cInput").value = cst_name;
		}
		function setParentTextFromList(cst_name){
			document.getElementById("cInput").value = cst_name;
			opener.document.getElementById("T*<?= $id ?>").innerHTML = document.getElementById("cInput").value;
			opener.document.getElementById("C*<?= $id ?>").value = document.getElementById("cInput").value;
		}
		function reLoad(){
			window.location = encodeURI("http://pda.daehyunst.com/pop/cname?id=<?= $id ?>&sh=" +  document.getElementById("cInput").value);
		}
	</script>
<body onload = "getParentText();">
	<div align = 'center'><b><font size="7" color="gray">업체명 입력</font></b></div>
	<table align = 'center'>
		<tr bgcolor="#B0C4DE">
			<td align = 'left'><input type="text" id="cInput" size='30'></td>
		</tr>
	</table>
	<table align = 'center'>
		<tr>
			<td><input type="button" value="검색" onclick="reLoad();"></td>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td><input type="button" value="확인" onclick="setParentText();window.close()"></td>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td><input type="button" value="취소" onclick="window.close();"></td>
		</tr>
	</table>
	<table width=<?= $d_width ?>>
		<tr bgcolor="#B0C4DE">
			<td align="center">업체명 리스트</td>
		</tr>
		<?php foreach ($data as $dt) { ?>
				<tr>
					<td align='left' onclick="setInputTextFromList('<?= $dt['cst_alias'] ?>')" ondblclick= "setParentTextFromList('<?= $dt['cst_alias'] ?>');window.close()"><?= $dt['cst_alias'] ?></td>
				</tr>
		<?php } ?>
	</table>
</body>
</html>