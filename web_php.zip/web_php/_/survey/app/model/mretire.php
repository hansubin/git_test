<?php

use Phalcon\Mvc\Model;

class mretire extends Model
{
	public $r_id;
	public $name;
	public $dept;
	public $age;
	public $gender;
	public $work_period;
	public $retire_Reason;
	public $free_word;
	public $con_yn;
	
	
}



?>