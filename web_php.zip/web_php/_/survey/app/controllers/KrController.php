<?php

use Phalcon\Mvc\Controller;
use Phalcon\Tag;

class KrController extends Controller
{
    public function indexAction()
    {
		 $this->dispatcher->forward(
            [
                "controller" => "survey",
                "action"     => "cs",
            ]
        );
		
		
    }
	
	
	
	
	
	
	
	
	
}

?>