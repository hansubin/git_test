<?php

use Phalcon\Mvc\Controller;
use Phalcon\Tag;

class AdminSurveyController extends Controller
{
	public static $dbid = 6; //0->live,6->test
	
    public function indexAction()
    {	
		try{
		//초과일시
		$Excess = '생성된지 30일이 지났습니다.';
		$query = "update mretire set r_code =:r_code where (current_date- i_date) > 30";
		$params = array(':r_code'=>$Excess);
		$stmt = $this->sql->execute($query,$params);

		//퇴직자명단 넘긴다.
		$sql = "select * from mretire";
		$params = array();
		$stmt = $this->sql->execute($sql,$params,self::$dbid);
		$r_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
		$rdata = $r_data;
		}catch(PDOException $e){
			$log = $e->getMessage();
            $this->logger->log($log);
		}
		$this->view->setVar('rdata',$rdata);
		
    }
	
}


?>