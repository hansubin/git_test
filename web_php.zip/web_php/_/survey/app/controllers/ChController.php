<?php

use Phalcon\Mvc\Controller;
use Phalcon\Tag;

class ChController extends Controller
{
	
    public function indexAction()
    {
		 $this->dispatcher->forward(
            [
                "controller" => "survey",
                "action"     => "csch",
            ]
        );
		
		
    }
	
	
	
	
	
	
	
	
	
}

?>