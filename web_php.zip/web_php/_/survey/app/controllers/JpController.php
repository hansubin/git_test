<?php

use Phalcon\Mvc\Controller;
use Phalcon\Tag;

class JpController extends Controller
{
	
    public function indexAction()
    {
		 $this->dispatcher->forward(
            [
                "controller" => "survey",
                "action"     => "csjp",
            ]
        );
		
		
    }
	
	
	
	
	
	
	
	
	
}

?>