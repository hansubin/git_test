<?php

use Phalcon\Mvc\Controller;
use Phalcon\Tag;

class VnController extends Controller
{
    public function indexAction()
    {
		 $this->dispatcher->forward(
            [
                "controller" => "survey",
                "action"     => "csvn",
            ]
        );
		
		
    }
	
	
	
	
	
	
	
	
	
}

?>