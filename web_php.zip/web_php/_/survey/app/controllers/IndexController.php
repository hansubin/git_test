<?php

use Phalcon\Mvc\Controller;

class IndexController extends Controller
{
    public function indexAction()
    {
		/*
		//다른 컨트롤러로 바로 이동. 20180219
		// "params" 쓸경우 매개인자값을 전달 할 수 있다.
		 $this->dispatcher->forward(
            [
                "controller" => "adminsurvey",
                "action"     => "index",
            ]
        );
		*/
    }
	
	
	
}

?>