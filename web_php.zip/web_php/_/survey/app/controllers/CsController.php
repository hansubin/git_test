<?php

use Phalcon\Mvc\Controller;
use Phalcon\Tag;

class CsController extends Controller
{
	
    public function indexAction()
    {
		 $this->dispatcher->forward(
            [
                "controller" => "survey",
                "action"     => "cs",
            ]
        );
		
		
    }
	
	
	
	
	
	
	
	
	
}

?>