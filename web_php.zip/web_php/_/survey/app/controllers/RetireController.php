<?php

use Phalcon\Mvc\Controller;

class RetireController extends Controller
{
    public function indexAction()
    {
		
		
		 $this->dispatcher->forward(
            [
                "controller" => "survey",
                "action"     => "retire",
            ]
        );
		
    }
	
	
	
}

?>