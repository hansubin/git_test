<?php
use Phalcon\Mvc\Controller;
use Phalcon\Tag;
use Phalcon\Crypt;

class PrintController extends Controller
{
	public static $dbid = 8; //0->live,6->test
	
    public function indexAction()
    {	
		
		$name = $this->request->getPost('r_name');
		$dept = $this->request->getPost('r_dept');
		$id = $this->request->getPost('r_id');
		
		$crypt = new Crypt();
		$key = $name;
		$str = "encryptiongo" ;
		
		//암호화
		$encrypted = $crypt -> encryptBase64 ( $str , $key );
		$this->view->setVar('rdata',$encrypted);
			
		//복호화
		$decrypted = $crypt -> decryptBase64( $encrypted , $key );
		$this->view->setVar('ndata',$decrypted);
		
		//문자열 합치기
		$thing = $name . $dept . $encrypted;
		$this->view->setVar('adata',$thing);
		try{
		
		$rdata = '암호화한값';
		
		$query = "update mretire set r_code=:r_code where r_id =:r_id";
		$params = array(':r_code'=>$encrypted,':r_id'=>$id);
		$stmt = $this->sql->execute($query,$params);
		
		}catch(PDOException $e){
			$log = $e->getMessage();
            $this->logger->log($log);
		}
		
		
		
		
    }
	
}


?>