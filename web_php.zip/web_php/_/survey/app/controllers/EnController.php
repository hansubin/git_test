<?php

use Phalcon\Mvc\Controller;
use Phalcon\Tag;

class EnController extends Controller
{
    public function indexAction()
    {
		 $this->dispatcher->forward(
            [
                "controller" => "survey",
                "action"     => "csen",
            ]
        );
		
		
    }
	
	
	
	
	
	
	
	
	
}

?>