<?php
use Phalcon\Tag;
use Phalcon\Loader;
use Phalcon\Mvc\View;
use Phalcon\Db\Adapter\Pdo\Postgresql as DbAdapter;
use Phalcon\Session\Adapter\Files as Session;
use Phalcon\Mvc\Application;
use Phalcon\Di\FactoryDefault;
use Phalcon\Logger\Adapter\File as Logger;
use Phalcon\Mvc\Url as UrlProvider;
use Phalcon\Http\Response;
include_once("/var/lib/php/db_dsn.php");
//pda 인덱스 폴더에서 가져온거
class Sql
{
  private $db, $stmt;
  //private $logger;
  
	public function execute($prepare, $bind_params = array(), $dbnum = 6) {
      if($dbnum == 6) $this->db = new PDO(pg_dsn);
      else if($dbnum == 7) $this->db = new PDO(pg_dsn7);
      else if($dbnum == 1) $this->db = new PDO(ms_dsn1,ms_user,ms_pwd);
      else if($dbnum == 2) $this->db = new PDO(ms_dsn2,ms_user,ms_pwd);
      else if($dbnum == 3) $this->db = new PDO(ms_dsn3,ms_user,ms_pwd);
      else if($dbnum == 4) $this->db = new PDO(ms_dsn4,ms_user,ms_pwd);
      else if($dbnum == 5) $this->db = new PDO(ms_dsn5,ms_user,ms_pwd);
	  else if($dbnum == 8) $this->db = new PDO(pg_dsn8);//8번째 추가.
      $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$this->stmt = $this->db->prepare($prepare);
			$this->stmt->execute($bind_params);
			//$this->logger->log(strtr($stmt->queryString,$bind_params));
			return $this->stmt;
	}
}
define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . '/app');

// Register an autoloader
$loader = new Loader();

$loader->registerDirs(
    [
        APP_PATH . '/controllers/',
        APP_PATH . '/models/',
    ]
);

$loader->register();

// Create a DI
$di = new FactoryDefault();

// Setup the view component
$di->set(
    'view',
    function () {
        $view = new View();
        $view->setViewsDir(APP_PATH . '/views/');
       $view->registerEngines(array(
			'.volt' => function($view, $di) {
			$volt = new VoltEngine($view, $di);
			$volt->setOptions(array(
				'compileAlways' => true
			));
			return $volt;
		},
			'.volt' => 'Phalcon\Mvc\View\Engine\Volt'
		));
		return $view;
    }
);

// Setup a base URI
$di->set(
    'url',
    function () {
        $url = new UrlProvider();
        $url->setBaseUri('/');
        return $url;
    }
);

$di['sql'] = function() use ($di) {
		$sql = new Sql();
		return $sql;
	};
	
	$di['session'] = function() {
		$session = new Session();
		$session->start();
		return $session;
	};
	


//use logger after DI created
	$di['logger'] = function() {
		$logger = new Logger('/var/log/php-fpm/survey'.date("Ymd").'.log');
		return $logger;
	};

$application = new Application($di);

try {
    // Handle the request
    $response = $application->handle();

    $response->send();
} catch (\Exception $e) {
    echo 'Exception: ', $e->getMessage();
}