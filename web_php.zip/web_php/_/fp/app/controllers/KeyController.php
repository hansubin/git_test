<?php

use Phalcon\Mvc\Controller;

class KeyController extends Controller
{

	public function indexAction()
	{
		// $lgn_id = $this->session->get('user')['id'];
		// $lgn_nm = iconv('EUC-KR','UTF-8', $this->session->get('user')['name']);
		// $this->view->setVar('lgn_id',$lgn_id );
		// $this->view->setVar('lgn_nm',$lgn_nm );
	}
        
	//upload sales proof
	public function Lz206u7uwKIiAction()
	{
            self::upAction("/home/webapps/ROOT/php/fp/public/upload/salp002/");
	}
        
        //download sales proof
	public function HmVbBeGT94EnAction()
	{
            self::downAction("/home/webapps/ROOT/php/fp/public/upload/salp002/");		
	}

	//upload sales ship
	public function KXdKXipN5SUdAction()
	{
            //쓰기시도하는 아이디 알아내기
            //$test_log = exec('whoami');
            //$this->logger->log("whoami --> '{$test_log}'");
            self::upAction("/home/webapps/ROOT/php/fp/public/upload/salp001/");
	}        
        
        //download sales ship
	public function BxLBuceDSqCPAction()
	{
            self::downAction("/home/webapps/ROOT/php/fp/public/upload/salp001/");		
	}
        
        private function upAction($dir)
        {
            //for only mybuilder
            $src = "[Agent]".trim($_SERVER['HTTP_USER_AGENT']);
            if(strpos($src,'MyBuilder') == false)
            {
                    $this->logger->log("illegal try from '{$src}'");
                    exit(1);
            }
             try {
                    $name = $this->request->getPost('name');
                    $data = base64_decode($this->request->getPost('data'));
                    $append = $this->request->getPost('append');
                    $end = $this->request->getPost('end');
                    ini_set('memory_limit', '128M'); 

                    if($append >= 1){ 
                            $old_data = file_get_contents($dir.$name); 
                            $result_save = file_put_contents($dir.$name, $old_data.$data); 
                            $size = $result_save." bytes."; 
                    }else{ 
                            $result_save = file_put_contents($dir.$name, $data); 
                            $size = $result_save." bytes.";
                    }
                    echo $size;
            } catch(PDOException $e){
                    $log = $e->getMessage();
                    $this->logger->log($log);
            }
        }
        
        private function downAction($dir)
        {
            //for only mybuilder
		$src = "[Agent]".trim($_SERVER['HTTP_USER_AGENT']);
		if(strpos($src,'MyBuilder') == false)
		{
			$this->logger->log("illegal try to download from '{$src}'");
			exit(1);
		}
		 try {
			$name = $this->request->getPost('id');
			$data = file_get_contents($dir.$name); 
			echo $data;
		} catch(PDOException $e){
			$log = $e->getMessage();
			$this->logger->log($log);
		}
        }
}