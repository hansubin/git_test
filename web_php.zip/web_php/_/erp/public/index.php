<?php
use Phalcon\Tag;
use Phalcon\Loader;
use Phalcon\Mvc\Url;
use Phalcon\Mvc\View;
use Phalcon\Mvc\Application;
use Phalcon\DI\FactoryDefault;
use Phalcon\Logger\Adapter\File as Logger;
use Phalcon\Session\Adapter\Files as Session;
use Phalcon\Http\Response;
include_once("/var/lib/php/db_dsn.php");

class Sql
{
  private $db, $stmt;
  //private $logger;
  
	public function execute($prepare, $bind_params = array(), $dbnum = 6) {
      if($dbnum == 6) $this->db = new PDO(pg_dsn);
      else if($dbnum == 7) $this->db = new PDO(pg_dsn7);
      else if($dbnum == 1) $this->db = new PDO(ms_dsn1,ms_user,ms_pwd);
      else if($dbnum == 2) $this->db = new PDO(ms_dsn2,ms_user,ms_pwd);
      else if($dbnum == 3) $this->db = new PDO(ms_dsn3,ms_user,ms_pwd);
      else if($dbnum == 4) $this->db = new PDO(ms_dsn4,ms_user,ms_pwd);
      else if($dbnum == 5) $this->db = new PDO(ms_dsn5,ms_user,ms_pwd);
			$this->stmt = $this->db->prepare($prepare);
			$this->stmt->execute($bind_params);
			//$this->logger->log(strtr($stmt->queryString,$bind_params));
			return $this->stmt;
	}
}
 
try {
	// Register an autoloader
	$loader = new Loader();
	$loader->registerDirs(
		array(
			'../app/controllers/',
			'../app/models/'
		)
	)->register();

	// Create a DI
	$di = new FactoryDefault();

	//use session for use security->checkToken
	$di['session'] = function() {
		$session = new Session();
		$session->start();
		return $session;
	};
	if( ($_GET['_url'] == '/' or ($_GET['_url'] != '' && $_GET['_url'] != '/login' && $_GET['_url'] != '/login/mypage' && $_GET['_url'] != '/login/record')) && empty($di['session']->get('user')['erp_id']) )
	{
		header("Location:../erp");
		exit(1);
	}
	
	//use logger after DI created
	$di['logger'] = function() {
		$logger = new Logger('/var/log/php-fpm/erp'.date("Ymd").'.log');
		return $logger;
	};
	
	// Set the database service
	$di['sql'] = function() use ($di) {
		$sql = new Sql();
		return $sql;
	};

	// Setting up the view component, 
	// use ($di) for not define error
	$di['view'] = function() use ($di) {
		$view = new View();
		$view->setViewsDir('../app/views/');
		$view->registerEngines(array(
			'.volt' => function($view, $di) {
			$volt = new VoltEngine($view, $di);
			$volt->setOptions(array(
				'compileAlways' => true
			));
			return $volt;
		},
			'.volt' => 'Phalcon\Mvc\View\Engine\Volt'
		));
		return $view;
	};

	// Setup a base URI so that all generated URIs include the 'tutorial' folder
	$di['url'] = function() {
		$url = new Url();
		$url->setBaseUri('/erp/');
		return $url;
	};

	// Setup the tag helpers
	$di['tag'] = function() {
		return new Tag();
	};

	ini_set('include_path', '/home/webapps/ROOT/php/erp/public');
	// Handle the request
	$application = new Application($di);
	echo $application->handle()->getContent();

} catch (Exception $e) {
	$di['logger']->log($e->getMessage());
}