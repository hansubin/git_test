<?php
use Phalcon\Mvc\Controller;

class LoginController extends Controller
{
	public function indexAction()
	{
		// if (!$this->security->checkToken()) {
			// header("Location:/erp/");
			// exit(1);
		// }
		$id = $this->request->getPost('userid','string');
		$pwd = $this->request->getPost('dst_ps','string');
		// $stmt = $this->db[$dbnum]->prepare($prepare);
		// $stmt->execute($bind_params);

		$stmt = $this->sql->execute(
			"select emp_no,emp_nm from xempmst where emp_stt = 'J01' and (emp_no ilike :login or emp_id ilike :login) and web_pass = crypt(:pwd, web_pass)",
			array(':login'=>$id,':pwd'=>$pwd)
		);
		
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		if ( isset($row['emp_nm']))
		{
			$this->session->set('user',array('erp_id'=>$row['emp_no'],'erp_nm'=>$row['emp_nm']));
			$this->logger->log('로그인 성공 erp_id:'.$this->session->get('user')['erp_id'].',erp_nm:'.$this->session->get('user')['erp_nm']);
			header("Location:/erp/login/main");
			exit(1);
		}
		else
		{
			$this->logger->log($row['emp_nm'].', 로그인실패 - id:'.$id.',pwd:'.$pwd);
		}
	}
	

	public function mainAction()
	{
		//Add some local CSS resources
		setcookie ('test', 'testval',time() + 60, '/', 'erp.daehyunst.com', 0, 1);
		$this->logger->log('login/main erp_id:'.$this->session->get('user')['erp_id'].',erp_nm:'.$this->session->get('user')['erp_nm'].'cookie = '.$_COOKIE['PHPSESSID']);
		$this->assets->addJs('js/MyBuilderViewer32U.js');
		$this->view->setVar('lgn_id',$this->session->get('user')['erp_id']);
		$this->view->setVar('lgn_nm',$this->session->get('user')['erp_nm']);
		$this->view->setVar('title','로그인');
	}
	
	public function mypageAction()
	{
		$user_id = $this->request->get('user_id');
		$stmt = $this->sql->execute(
			"select emp_nm from xempmst where emp_stt = 'J01' and (emp_no ilike :login or emp_id ilike :login)",
			array(':login'=>$user_id)
		);
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		$this->session->set('user',array('erp_id'=>$user_id,'erp_nm'=>$row['emp_nm']));
		$this->assets->addCss('css/style.css');
		$this->view->setVar('emp_no',$user_id);
		$this->view->setVar('emp_nm',$row['emp_nm']);
		$this->view->setVar('title','정보변경');
	}
	
	public function recordAction()
	{
		$user_id = $this->session->get('user')['erp_id'];
		$dst_ps = $this->request->getPost('dst_ps');
		$dst_ps_new = $this->request->getPost('dst_ps_new');
		//$this->logger->log('user_id:'.$user_id.',dst_ps:'.$dst_ps.',dst_ps_new:'.$dst_ps_new);
		$stmt = $this->sql->execute(
			"select emp_nm from xempmst where emp_stt = 'J01' and (emp_no ilike :login or emp_id ilike :login) and web_pass = crypt(:pwd, web_pass)",
			array(':login'=>$user_id,':pwd'=>$dst_ps)
		);
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		if(isset($row['emp_nm'])){
			$query = "update xempmst set web_pass = crypt(:pwd,gen_salt('des')) where ((emp_no = :login and emp_no is not null) or (emp_id ilike :login and emp_id is not null))";
			$params = array(':login'=>$user_id,':pwd'=>$dst_ps_new);
			$stmt = $this->sql->execute($query,$params);
			//$this->logger->log(IndexController::pdo_sql_debug($query,$params));
			$this->logger->log('기존 암호 변경 성공:'.$user_id);
			$this->view->setVar('success','true');
		}
		else{
			$this->logger->log('기존 암호 변경 실패:'.$user_id);
			$this->view->setVar('success','false');
		}
		$this->view->setVar('emp_no',$user_id);
		$this->assets->addCss('css/style.css');
		$this->view->setVar('title','정보변경');
	}
}