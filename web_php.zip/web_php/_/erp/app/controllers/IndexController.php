<?php

use Phalcon\Mvc\Controller;
use Phalcon\Tag;

class IndexController extends Controller
{
	public static $dbid = 6;//0->live,6->test
	
	public function indexAction()
	{
		//Add some local CSS resources
		$this->assets->addCss('css/style.css');
		$this->view->setVar('title','로그인');
	}

	public function it_infraAction()
	{
		//Add some local CSS resources
		$this->assets->addCss('css/style.css');
		$this->view->setVar('title','로그인');
	}	
	
	function pdo_sql_debug($sql,$placeholders){
		foreach($placeholders as $k => $v){
			$sql = preg_replace('/'.$k.'/',"'".$v."'",$sql);
		}
		return $sql;
	}
}