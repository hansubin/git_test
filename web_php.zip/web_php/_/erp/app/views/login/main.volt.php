<html>
<head>
<title>대현에스티통합정보시스템</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no">
<script language="JavaScript">
<!--
	function OnOpen()
	{
		View1.CoreDLL = "MyBuilderControlU.dll";
		View1.SetParameter("_COOKIE_", document.cookie);
		View1.SetEnv("dhsterp", "http://erp.daehyunst.com/dstmyb/Files", "DaehyunST");
		View1.FileName="(MDI)";
		View1.UserID = "<?= $lgn_id ?>";
		View1.SetParameter("user_id", "<?= $lgn_id ?>");
		View1.SetParameter("user_nm", "<?= $lgn_nm ?>");
		View1.SetParameter("g_first_dbid", "6");
		View1.SetParameter("g_second_dbid", "0");
		View1.Embed = true;
		View1.ToolBar = false;
		View1.StatusBar = false;
		View1.RunMode =32;
		View1.Run();
		View1.focus();
	}
// -->
</script>
<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" onload="OnOpen();">
<?= $this->assets->outputJs() ?>
</body>
</html>