<html>
<head>
	<title><?= $title ?></title>
	<meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, width=device-width, height=device-height">
	<?= $this->assets->outputCss() ?>
</head>
<body>
<table width="223" bgcolor="gray"><tr><td align="center"><h2><?= $title ?></h2></td></tr></table>
	<form action="mypage" method="post">
	<table width="223">
	<?php if ($success == 'true') { ?>
		<tr>
			<td>
				성공적으로 정보가 변경되었습니다.
			</td>
		</tr>
		<tr>
			<td height="20" colspan="2" align="center"><input type="button" value="확   인" onclick="javascript:window.close();"/></td>
		</tr>
	<?php } else { ?>
		<tr>
			<td>
				정보변경에 실패했습니다. 다시한번 시도해주세요
				<input id="user_id" type="hidden" name="user_id" size="17" value="<?= $emp_no ?>"/>
			</td>
		</tr>
		<tr>
			<td height="20" colspan="2" align="center"><input type="submit" value="확   인"/></td>
		</tr>
	<?php } ?>
	</table>
	</form>
</body></html>