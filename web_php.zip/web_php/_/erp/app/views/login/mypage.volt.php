<html>
<head>
	<title><?= $title ?></title>
	<meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, width=device-width, height=device-height">
	<?= $this->assets->outputCss() ?>
</head>
<body onLoad="parent.resizeTo(300,400);" >
<table width="223" bgcolor="gray"><tr><td align="center"><h2><?= $title ?></h2></td></tr></table>
	<form action="record" method="post">
	<table width="223">
		<tr>
			<td colspan="2">*기존 암호를 넣어야 변경 됩니다. 암호는 8자이상 영문/숫자를 반드시 포함하세요.</td>
		</tr>
		<tr>
			<td width="120"><label for="user_nm">이&nbsp;&nbsp;&nbsp;&nbsp;름</label></td>
			<td><input id="user_id" type="hidden" name="user_id" size="17" value="<?= $emp_no ?>"/><input id="user_nm" type="text" name="user_nm" size="17" value="<?= $emp_nm ?>"/></td></tr>
		<tr>
			<td width="120"><label for="dst_ps">기존&nbsp;&nbsp;암호</label></td>
			<td><input id="dst_ps" type="password" name="dst_ps" size="17" value=""/></td>
		</tr>
		<tr>
			<td width="120"><label for="dst_ps_new">새로운 암호</label></td>
			<td><input id="dst_ps_new" type="password" name="dst_ps_new" size="17"/></td>
		</tr>
		<tr>
			<td height="20" colspan="2" align="center"><input type="submit" value="변   경"/></td>
		</tr>
	</table>
	</form>
</body></html>