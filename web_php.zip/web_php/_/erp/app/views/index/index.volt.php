<html>
<head>
<title>DST ERP</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no">
<script language="JavaScript">
<!--
function na_open_window(name, url, left, top, width, height, toolbar, menubar, statusbar, scrollbar, resizable)
{
  toolbar_str = toolbar ? 'yes' : 'no';
  menubar_str = menubar ? 'yes' : 'no';
  statusbar_str = statusbar ? 'yes' : 'no';
  scrollbar_str = scrollbar ? 'yes' : 'no';
  resizable_str = resizable ? 'yes' : 'no';
  cookie_str = document.cookie;
  cookie_str.toString();
  pos_start  = cookie_str.indexOf(name);
  pos_start  = cookie_str.indexOf('=', pos_start);
  pos_end    = cookie_str.indexOf(';', pos_start);

  if (pos_end <= 0) pos_end = cookie_str.length;
  cookie_val = cookie_str.substring(pos_start + 1, pos_end);
  if (cookie_val  == "done")return;
  window.open(url, name, 'left='+left+',top='+top+',width='+width+',height='+height+',toolbar='+toolbar_str+',menubar='+menubar_str+',status='+statusbar_str+',scrollbars='+scrollbar_str+',resizable='+resizable_str);
}
// --></script>
</head>
<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" text="black" vlink="black">
<?= $this->tag->form(['login', 'method' => 'post']) ?>

<table width="100%" border="0" cellspacing="0" cellpadding="0" bordercolor="white" bordercolordark="white" bordercolorlight="white" style="border-color:white;">
<tr bordercolor="white" bordercolordark="white" bordercolorlight="white" style="border-color:white;">
	<td align="center" bgcolor="#f0f0f0" bordercolordark="white" bordercolorlight="white">
		<table width="904" border="0" cellspacing="0" cellpadding="0" bordercolordark="white" bordercolorlight="white">
			<tr>
				<td height="644" align="center" valign="top" background="/erp/img/loginbg.gif" style="padding-left:1px;">
					<table width="773" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td style="padding-top:28px;" height="176" rowspan="2" width="199">
								<p align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="144" height="126">
									<param name="movie" value="/erp/img/monitor.swf">
									<param name="play" value="true">
									<param name="loop" value="true">
									<param name="quality" value="high">
									<embed width="144" height="126" src="/erp/img/monitor.swf" play="true" loop="true" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></embed></object></p>
							</td>
							<td width="574" height="130" style="padding-top:28px;">
								<p align="left"><font face="바탕">&nbsp;</font></p>
								<div style="width:566; height:42; float:left;">
									<p><span style="font-size:28pt;"><i><font color="#0000CC">대현에스티 통합정보시스템</font></i></span></p>
								</div>
								<p align="left">&nbsp;</p>
							</td>
						</tr>
						<tr>
							<td width="574" height="7" style="padding-top:28px;">&nbsp;</td>
						</tr>
						<tr>
							<td align="center" colspan="2" width="773">
								<table width="702" border="0" cellspacing="0" cellpadding="0">
									<tr>
										<td>
											<table width="702" border="0" cellspacing="0" cellpadding="0">
												<tr>
													<td style="padding-top:19px; padding-left:22px;" height="238">
														<p align="left"><img src="/erp/img/loginimg_14.gif" width="91" height="17" /></p>
														<table border="1" width="666" bordercolor="white" bordercolordark="white" bordercolorlight="white">
															<tr>
																<td width="64" height="44" bordercolor="white" bordercolordark="white" bordercolorlight="white">
																	<img src="/erp/img/loginimg_21.gif" width="64" height="21" />
																</td>
																<td width="163" height="44" bordercolor="white" bordercolordark="white" bordercolorlight="white">
																	<p align="left"><?= $this->tag->textField(['userid', 'size' => 17]) ?></p>
																</td>
																<td width="64" height="44" bordercolor="white" bordercolordark="white" bordercolorlight="white">
																	<img src="/erp/img/loginimg_33.gif" width="64" height="21">
																</td>
																<td width="167" height="44" bordercolor="white" bordercolordark="white" bordercolorlight="white">
																	<?= $this->tag->passwordField(['dst_ps', 'size' => 17]) ?>
																</td>
																<td width="45" height="44" bordercolor="white" bordercolordark="white" bordercolorlight="white">
																	<?= $this->tag->submitButton(['로그인']) ?>
																</td>
																<td width="123" height="44" bordercolor="white" bordercolordark="white" bordercolorlight="white">&nbsp;</td>
															</tr>
														</table>
														<p align="left" style="line-height:150%; margin-top:0; margin-bottom:0;">
															<b><font color="red">처음 접속하시는 분들은 </font></b>
														</p>
														<p align="left" style="line-height:150%; margin-top:0; margin-bottom:0;">
															<a href="http://106.246.241.130/project/daehyunst.reg"><b><font color="red">여기</font></b></a><b>를 클릭하여 레지스트에 등록 바랍니다.</font></b>
														</p>
														<p align="left" style="line-height:150%; margin-top:0; margin-bottom:0;">
															<span style="font-size:9pt;"></span>
														</p>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</td>
</tr>
</table>
<?= $this->tag->hiddenField([$this->security->getTokenKey(), 'value' => $this->security->getToken()]) ?>
<?= $this->tag->endform() ?>